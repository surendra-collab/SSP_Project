require('dotenv').config();

const port = process.env.PORT;  // Socket Port
let express = require('express');
let moment = require('moment');
let app = express();
let http = require('http').Server(app); // Including http package and creating an application
let mysql = require('mysql');   //  Including mysql package123

if(process.env.FCM_FILEPATH != ""){
    var firebase_admin = require('firebase-admin');
    var firebase_path = process.env.FCM_FILEPATH;
    var serviceAccount = require(firebase_path);

    firebase_admin.initializeApp({
        credential: firebase_admin.credential.cert(serviceAccount)
    });
    const fcm = firebase_admin.messaging();
}

let user_default_img = "public/assets/common/images/default-avatar.png";

let io = require('socket.io')(http, {
    // cors: {
    //     origin: host_url,
    //     methods: ["GET", "POST"]
    // }
});    //  Including socket.io package


let con = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB,
    charset: 'utf8mb4',
    dateStrings: true
});


/*
    Setting mysql connection
*/
con.connect((err) => {
    if (err) {
        return showInLog(err);
    }
    showInLog("Database Connected");
    // setting default state of all users
    dbDefault();
});

let sockets = {};

app.get('/', function (req, res) {
    //res.render('chat', { socket_url: host_url });
    res.sendFile(__dirname + '/index.html');
});

/*
    Socket Connection Bridge
*/
io.on('connection', async function (socket) {

    //---------------- Show which user is gets connect -------------------------------------
    showInLog(`User Connected : ${socket.handshake.query.user_id}`);
    var user_id = socket.handshake.query.user_id;

    //---------------- Make a room in pool for the user if new user ------------------------
    if (!sockets[socket.handshake.query.user_id]) {
        sockets[socket.handshake.query.user_id] = [];
    }

    //---------------- Get user detail and add socket connection object in the pool array ----------------------
    await getUser(socket.handshake.query.user_id).then((user) => {
        socket.user_detail = user;
        sockets[socket.handshake.query.user_id].push(socket);
    }).catch((err) => {
        throw err;
    });

    //---------------- Update user online status -------------------------------------------
    updateOnlineStatus(socket.handshake.query.user_id);

    //---------------- Inform other users that I am online -------------------------------------------
    /*if (1) {
        for (let index in sockets) {
            if (index != socket.handshake.query.user_id) {
                for (let index_inner in sockets[index]) {
                    console.log(`start \n  ${sockets[index][index_inner]} \n end`);
                    sockets[index][index_inner].emit('update_user_list', { status: true, online: 1, user_id: socket.handshake.query.user_id, message: `user ${socket.user_detail.name} is online now` });
                }
            }
        }
        showInLog(`Informed other users that I am online : ${socket.handshake.query.user_id}`);
    }*/

    //---------------- Send Message -----------------------------------------
    socket.on('send_message', function (data, cb) {

        checkIfActive(user_id).then((activeStatus) => {
            if (activeStatus.status) {
                showInLog(data);
                saveMessage(user_id, data).then((result) => {
                    cb(result);

                    if (result.you_are_blocked != true) {

                        getUser(data.other_user_id).then((user_data) => {

                            data.other_user_image = user_data.profile_image;
                            data.sender_user_image = socket.user_detail.profile_image;

                            //=======send notification========//
                            let notification_extras = {
                                status: true,
                                message: "Message successfully sent.",
                                data: {
                                    group: data.group,
                                    message: data.message,
                                    receiver: data.other_user_id,
                                    receiver_name: user_data.user_name,
                                    receiver_image: data.other_user_image,
                                    sender: user_id,
                                    sender_name: socket.user_detail.user_name,
                                    sender_image: data.sender_user_image,
                                }
                            }

                            if (!(data.other_user_id in sockets)) {

                                let msg = socket.user_detail.user_name + ' sends you a new message.';
                                let msg_action = 'SEND_MSG';
                                initiatingNotification(data.other_user_id, msg, msg_action, notification_extras);

                            }



                            let receiver_data = {
                                // status: true,
                                id: result.id,
                                message: data.message,
                                message_type: data.type,
                                // is_delivered : 0,
                                receiver_status: 0,
                                sender: parseInt(socket.handshake.query.user_id),
                                sender_name: socket.user_detail.user_name,
                                created_at: result.created_at,
                                group: data.group,
                            }

                            showInLog(`receiver data :`, receiver_data);
                            // showInLog(`other user id data :`, sockets[data.other_user_id]);
                            for (let index in sockets[data.other_user_id]) {
                                sockets[data.other_user_id][index].emit('receive_message', receiver_data);
                                //fetched other user inbox list
                                let paginationState = {
                                    pagination: 0,
                                }
                                inboxList(data.other_user_id, paginationState).then((inbox_result) => {
                                    showInLog(`Other user Inbox list fetched : ${data.other_user_id}`, inbox_result);

                                    sockets[data.other_user_id][index].emit('receiver_inbox_listener', inbox_result);

                                }).catch((err) => {
                                    throw err;
                                })
                            }
                        }).catch((err) => {
                            throw err;
                        });

                    }

                }).catch((err) => {
                    throw err;
                });
            }
        }).catch((err) => {
            throw err;
        });
    });

    //...................get Other user details............................
    socket.on('other_user_details', function (data, cb) {
        showInLog('Other user ID', data);
        getUser(data.other_user_id).then((result) => {
            cb(result);
        });
    });

    //...................Message Seen by other user ............................
    socket.on('seen_by_other_user', function (data) {
        messageSeen(user_id, data).then((result) => {
            showInLog('Message seen by user');
        });
    });

    //---------------- Get my unread message count -----------------------------------------
    socket.on('unread_message', function (cb) {
        unreadMessageCount(socket.handshake.query.user_id).then((result) => {
            for (let index in sockets[socket.handshake.query.user_id]) {
                cb(result);
            }
        }).catch((err) => {
            throw err;
        })
    });

    //-------------------- Get my inbox list --------------------------
    socket.on('inbox_list', function (data, cb) {
        showInLog('Inbox list requested', data);
        inboxList(socket.handshake.query.user_id, data).then((result) => {
            showInLog(`Inbox list fetched : ${socket.handshake.query.user_id}`, result);
            cb(result);
        }).catch((err) => {
            throw err;
        })
    });

    //-------------------- Get Block User --------------------------
    socket.on('block_user', function (data, cb) {
        showInLog('Block user', data);
        checkIfActive(socket.handshake.query.user_id).then((activeStatus) => {
            if (activeStatus.status) {
                block_unblock_user(socket.handshake.query.user_id, data).then((result) => {
                    cb(result);
                    for (let index in sockets[data.other_user_id]) {
                        showInLog('block_user receiver listener');
                        showInLog(result);
                        sockets[data.other_user_id][index].emit('block_unblock_listener', result);
                    }
                });
            } else {
                cb(activeStatus);
            }
        }).catch((err) => {
            throw err;
        });
    });

    //------------------- User Report --------------------------
    socket.on('report_user', function (data, cb) {
        checkIfActive(user_id).then((activeStatus) => {
            if (activeStatus.status) {
                reportUser(user_id, data).then((result) => {
                    showInLog(result);
                    cb(result);
                });
            } else {
                cb(activeStatus);
            }
        }).catch((err) => {
            throw err;
        });
    });

    //-------------------- Delete History --------------------------
    socket.on('delete_history', function (data, cb) {
        showInLog('deleted data', data);
        delete_history(user_id, data).then((result) => {
            cb(result);
        }).catch((err) => {
            throw err;
        })
    });

    //---------------- Get other user list -----------------------------------------
    socket.on('user_list', function (cb) {
        userList(socket.handshake.query.user_id).then((result) => {
            for (let index in sockets[socket.handshake.query.user_id]) {
                cb(result);
            }
        }).catch((err) => {
            throw err;
        })
    });

    //--------------------------- Disconnect user----------------------------------
    socket.on('disconnect', function (reason) {
        showInLog(`User Disconnected : ${socket.handshake.query.user_id}`);
        showInLog(`Reason : ${reason}`);

        //---------------- Update user online status -------------------------------------------
        updateOnlineStatus(socket.handshake.query.user_id, 0);

        //---------------- Inform other users that I am going offline -------------------------------------------
        /*if (1) {
            for (let index in sockets) {
                if (index != socket.handshake.query.user_id) {
                    for (let index_inner in sockets[index]) {
                        sockets[index][index_inner].emit('update_user_list', { status: true, online: 0, user_id: socket.handshake.query.user_id, message: `user ${socket.user_detail.name} is offline now` });
                    }
                }
            }
            showInLog(`Informed other users that I am online : ${socket.handshake.query.user_id}`);
        }*/

        //---------------- Remove user from socket pool array -------------------------------------------
        delete sockets[socket.handshake.query.user_id];
    });

    //-------------------- Get chat history --------------------------
    socket.on('chat_history', function (data, cb) {
        showInLog('Chat history requested', data);
        chatHistory(socket.handshake.query.user_id, data).then((result) => {
            result.online = false;
            for (const index in sockets[data.user_id]) {
                result.online = true;
            }
            cb(result);
            for (let index in sockets[data.user_id]) {
                sockets[data.user_id][index].emit('message_seen', { status: true, message: "Messages seen", seen_by: socket.handshake.query.user_id });
            }
        }).catch((err) => {
            throw err;
        })
    });
});

//------------------ Update online status -------------------
function updateOnlineStatus(user_id, status = 1) {
    new Promise((resolve, reject) => {
        let qry = `UPDATE users SET online = ${status} WHERE id = ${user_id}`;
        con.query(qry, function (err, result) {
            if (err) {
                showInLog(err);
                return reject(err);
            }
            status ? (function () {
                showInLog(`User ${user_id} : ONLINE`);
                // messageDelivered(user_id);  // update message status AS delivered
            })() : showInLog(`User ${user_id} : OFFLINE`);


            return resolve(true);
        });
    });
}

//------------------ Save messimageage -----------------------
function saveMessage(sender, data) {
    return new Promise((resolve, reject) => {
        checkIfBlock(sender, data).then((res) => {
            if (res.status || res.data === 'YOU_ARE_BLOCKED') {
                let receiver_status = 0;    // offline
                for (let index in sockets[data.user_id]) {
                    receiver_status = 1;     // online
                }

                var blocked_status = false;
                var blocked_user = 0;

                if (res.data === 'YOU_ARE_BLOCKED') {
                    blocked_user = sender;
                    blocked_status = true;
                }

                let qry = 'INSERT INTO chats (sender, receiver, message, message_type, group_code, blocked_user, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';

                let values = [sender, data.other_user_id, data.message, data.type, data.group, blocked_user, moment().utc().format("YYYY-MM-DD HH:mm"), moment().utc().format("YYYY-MM-DD HH:mm")];


                con.query(qry, values, function (err, result) {
                    if (err) {
                        return reject(err);
                    }


                    return resolve(
                        {
                            status: true,
                            message: "Message successfully saved.",
                            id: result.insertId,
                            message: data.message,
                            sender: parseInt(sender),
                            created_at: moment().utc().format("YYYY-MM-DD HH:mm"),
                            message_type: data.type,
                            group: data.group,
                            you_are_blocked: blocked_status,
                        });
                });
            } else {
                return resolve(res);
            }
        });
    });
}

//------------------ Update message seen status -------------------
function messageSeen(user_id, data) {

    return new Promise((resolve, reject) => {
        let qry = `UPDATE chats SET is_seen = 1, updated_at = CURRENT_TIMESTAMP WHERE receiver = ${user_id} and group_code = '${data.group}' and is_seen = 0`;
        showInLog(`message seen ${qry}`);
        con.query(qry, function (err, result) {
            if (err) {
                showInLog("error occurred");
                return reject(err);
            }
            showInLog(`Messages Seen By User : ${user_id}`);
            return resolve(true);
        });
    });
}

//------------------ Unread Message Count -------------------
function unreadMessageCount(user_id) {
    return new Promise((resolve, reject) => {
        let qry = `SELECT count(*) AS unread_message FROM chats WHERE receiver = ${user_id} and is_seen = 0`;
        con.query(qry, function (err, result) {
            if (err) {
                return reject(err);
            }
            showInLog(`Unread Message of ${user_id} : ${result[0].unread_message}`)
            resolve(result[0]);
        });
    });
}

//------------------ Get inbox list -------------------
function inboxList(user_id, data) {
    /*
    let query = `SELECT
                chats.id, chats.message, chats.message_type, chats.group_code, chats.is_delivered, chats.is_seen,chats.created_at, chats.sender as last_sent_by,chats.deleted_by, chats.blocked_user,

                CASE WHEN sender.id = ${user_id} THEN receiver.id ELSE sender.id END AS user_id,
                CASE WHEN unread_list.unread_message is null THEN 0 else unread_message END as unread_message,
                CASE WHEN chats.sender = ${user_id} THEN receiver.user_name ELSE sender.user_name END AS user_name,
                CASE WHEN chats.sender = ${user_id} THEN
                        CASE WHEN receiver.profile_qr is null THEN '${user_default_img}' ELSE receiver.profile_qr END
                    ELSE
                        CASE WHEN sender.profile_qr is null THEN '${user_default_img}' ELSE sender.profile_qr END
                END AS other_user_image,
                CASE WHEN chats.sender = ${user_id} THEN receiver.online ELSE sender.online END AS online
                FROM chats
                LEFT JOIN users AS sender ON sender.id=chats.sender
                LEFT JOIN users AS receiver ON receiver.id=chats.receiver
                LEFT JOIN (SELECT group_code, COUNT(*) AS unread_message FROM chats WHERE receiver = ${user_id} AND is_seen = 0 GROUP BY group_code) as unread_list on unread_list.group_code = chats.group_code
                WHERE (chats.sender = ${user_id} OR chats.receiver = ${user_id}) AND chats.id IN (SELECT MAX(id) FROM chats WHERE chats.group_type = 'SINGLE' GROUP BY group_code)
                ORDER BY chats.id DESC`;
    */

    let query = `SELECT
                chats.id, chats.message, chats.message_type, chats.group_code, chats.is_delivered, chats.is_seen,chats.created_at, chats.sender as last_sent_by,chats.deleted_by, chats.blocked_user,

                CASE WHEN sender.id = ${user_id} THEN receiver.id ELSE sender.id END AS user_id,
                CASE WHEN unread_list.unread_message is null THEN 0 else unread_message END as unread_message,
                CASE WHEN chats.sender = ${user_id} THEN receiver.user_name ELSE sender.user_name END AS user_name,
                CASE WHEN chats.sender = ${user_id} THEN
                        CASE WHEN receiver.profile_picture is null THEN '${user_default_img}' ELSE receiver.profile_picture END
                    ELSE
                        CASE WHEN sender.profile_picture is null THEN '${user_default_img}' ELSE sender.profile_picture END
                END AS other_user_image,
                CASE WHEN chats.sender = ${user_id} THEN receiver.online ELSE sender.online END AS online
                FROM chats
                LEFT JOIN users AS sender ON sender.id=chats.sender
                LEFT JOIN users AS receiver ON receiver.id=chats.receiver
                LEFT JOIN (SELECT group_code, COUNT(*) AS unread_message FROM chats WHERE receiver = ${user_id} AND is_deleted = 0 AND is_seen = 0  AND blocked_user = 0 GROUP BY group_code) as unread_list on unread_list.group_code = chats.group_code
                WHERE (
                    (chats.sender = ${user_id} OR chats.receiver = ${user_id})
                    AND chats.id IN (
                        SELECT MAX(id)
                        FROM chats
                        WHERE group_type = 'SINGLE'
                        AND (
                            (chats.blocked_user = ${user_id} AND chats.blocked_user != 0)
                            OR
                            (chats.blocked_user = 0)
                        )
                        GROUP BY group_code
                    )
                )
                ORDER BY chats.id DESC`;
    if (data.pagination) {
        let page = +data.page;
        let limit = +data.limit;
        let offset = (page - 1) * limit;
        query += ` limit ${offset}, ${limit}`;
    }
    return new Promise((resolve, reject) => {
        con.query(query, function (err, result) {
            if (err) {
                return reject(err);
            }
            if (data.pagination) {
                return resolve({ status: true, message: 'Inbox list successfully fetched', data: result, total_record: result.length, total_page: (result.length / limit), current_page: +data.page });
            }
            else {
                return resolve({ status: true, message: 'Inbox list successfully fetched', data: result, total_record: result.length });
            }
        });
    })
}

//------------------ Other User List -------------------
function userList(user_id) {
    return new Promise((resolve, reject) => {
        let qry = `SELECT id, user_name, online FROM users WHERE id != ${user_id} order by user_name`;
        con.query(qry, function (err, result) {
            if (err) {
                return reject(err);
            }
            resolve(result);
        });
    });
}

//------------------ Get user detail -------------------
function getUser(user_id) {
    return new Promise((resolve, reject) => {
        con.query(`SELECT id, user_name, case when profile_qr is null then '${user_default_img}' ELSE profile_qr end AS profile_image FROM users WHERE id = ${user_id} `, function (err, result) {
            if (err) {
                return reject(err);
            }
            return resolve(result[0]);

        })
    })
}



function delete_history(user_id, data) {
    return new Promise((resolve, reject) => {
        let qrysss = `SELECT * FROM chats WHERE group_code = '${data.group}' AND is_deleted = 0`;
        con.query(qrysss, function (err, result) {
            if (err) {
                return reject(err);
            }

            if (result.length !== 0) {

                let qry = `UPDATE chats SET is_deleted = 1, deleted_by = ${user_id}, updated_at = CURRENT_TIMESTAMP WHERE group_code = '${data.group}' AND is_deleted = 0`;
                con.query(qry, function (err, result) {
                    if (err) {
                        return reject(err);
                    }


                    let delete_qry = `DELETE FROM chats WHERE group_code = '${data.group}' AND is_deleted = 1 AND deleted_by != ${user_id}`;
                    con.query(delete_qry, function (err, result) {
                        if (err) {
                            return reject(err);
                        }

                        let response = {
                            status: true,
                            message: 'Data updated successfully.',
                            data: {},
                            group: data.group,
                        }
                        showInLog(response);
                        return resolve(response);

                    });

                });

            }
            else {
                //hard delete if it deleted by one user and then another user try to delete it.

                let qry = `DELETE FROM chats WHERE group_code = '${data.group}' AND is_deleted = 1 AND deleted_by != ${user_id}`;
                con.query(qry, function (err, result) {
                    if (err) {
                        return reject(err);
                    }


                    let insert_qry = 'INSERT INTO chats (sender, receiver, message, message_type, group_code, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)';

                    let values = [user_id, data.other_user_id, '', 'CLEARED', data.group, moment().utc().format("YYYY-MM-DD HH:mm"), moment().utc().format("YYYY-MM-DD HH:mm")];


                    con.query(insert_qry, values, function (err, result) {
                        if (err) {
                            return reject(err);
                        }

                        let response = {
                            status: true,
                            message: 'Data deleted successfully.',
                            data: {},
                            group: data.group,
                        }
                        showInLog(response);
                        return resolve(response);

                    });

                });
            }
        });
    });
}



//------------------ Db default status -------------------
function dbDefault() {
    new Promise((resolve, reject) => {
        let qry = `UPDATE users SET online = 0`;
        con.query(qry, function (err, result) {
            if (err) {
                return reject(err);
            }
            showInLog("DB successfully set to default");
            return resolve(true);
        });
    });
}

//------------------ Check user status -------------------
function checkIfActive(user_id) {
    return new Promise(function (resolve, reject) {
        var user_sql = "SELECT status FROM `users` WHERE id=" + user_id;

        showInLog(`user status qry = ${user_sql}`);
        con.query(user_sql, function (err, users) {
            if (err)
                reject(err);
            if (users.length > 0) {
                if (users[0].status) {
                    let response = {
                        status: true,
                        message: 'Your account is active',
                        data: {},
                    }
                    showInLog(response);
                    resolve(response);
                } else {
                    let response = {
                        status: false,
                        message: 'Your account has been deactivated, please contact to administrator.',
                        data: {},
                    }
                    showInLog(response);
                    resolve(response);
                }
                resolve(users[0].status);
            } else {
                let response = {
                    status: false,
                    message: 'Something went wrong, please try again.',
                    data: {},
                }
                showInLog(response);
                resolve(response);
            }
        });
    });
}

//-------------------- Block/Unblock user --------------------
function block_unblock_user(user_id, data) {
    return new Promise((resolve, reject) => {

        showInLog(data);
        if (data.status_key == 1) {
            let block_exist_qry = `SELECT count(*) as record_exist FROM block_users WHERE group_code = '${data.group}' AND blocked_by = ${user_id}`;

            con.query(block_exist_qry, function (err, result) {
                if (err) {
                    return reject(err);
                } else {

                    if (result[0].record_exist <= 0) {

                        let block_user_qry = `INSERT INTO block_users (blocked_by, blocked_to, group_code, created_at,updated_at) VALUES (${user_id}, ${data.other_user_id}, '${data.group}', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`;

                        con.query(block_user_qry, function (err, result) {
                            if (err) {
                                return reject(err);
                            } else {
                                showInLog("Blocked Successfully.");
                                var responseData = {
                                    status: true,
                                    message: "Blocked Successfully.",
                                    data: {
                                        block_by: parseInt(user_id),
                                        block_status: 1,
                                        group: data.group,
                                    }
                                };
                                resolve(responseData);
                            }
                        });
                    }
                }
            });
        } else {
            showInLog("******Unblock user*********");
            let unblock_user_qry = `DELETE FROM block_users WHERE blocked_by = ${user_id}  AND blocked_to =  ${data.other_user_id} AND group_code = '${data.group}'`;

            con.query(unblock_user_qry, function (err, result) {
                if (err) {
                    return reject(err);
                } else {

                    showInLog("Unblocked Successfully.");
                    var responseData = {
                        status: true,
                        message: "Unblocked Successfully.",
                        data: {
                            // block_by: parseInt(user_id),
                            block_by: 0,
                            block_status: 0,
                            group: data.group,
                        }
                    };
                    showInLog('user_block_unblock_response', responseData);
                    resolve(responseData);
                }
            });
        }
    });
}

//------------------- Report User ------------------------
function reportUser(user_id, data) {
    return new Promise((resolve, reject) => {
        let report_exist_qry = `Select count(*) as record_exist FROM report_users where reporter_id = ${user_id} AND group_code = ${data.group}`;
        showInLog(report_exist_qry);
        con.query(report_exist_qry, function (err, result) {
            if (err) {
                return reject(err);
            } else {
                if (result[0].record_exist > 0) {

                    showInLog("You already reported this account.");
                    var responseData = {
                        status: false,
                        message: "You already reported this account.",
                        data: {}
                    };
                    resolve(responseData);

                } else {


                    let desc = mysql.escape(data.description);

                    let report_user_qry = `INSERT INTO report_users (reporter_id, user_id, description, group_code, created_at, updated_at) values (${user_id}, ${data.other_user_id}, ${desc}, '${data.group}',CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`;
                    showInLog(report_user_qry);
                    con.query(report_user_qry, function (err, result) {
                        if (err) {
                            return reject(err);
                        } else {
                            showInLog("Reported successfully.");
                            var responseData = {
                                status: true,
                                message: "Reported successfully.",
                                data: {
                                    report_status: 1,
                                    group: data.group,
                                }
                            };
                            resolve(responseData);
                        }
                    });
                }
            }
        });
    });
}

//------------------ Get chat history -------------------
function chatHistory(user_id, data) {
    return new Promise((resolve, reject) => {

        let page = 1, limit = 10, offset;

        checkIfBlock(user_id, data).then((res) => {

            var query = `SELECT id, message, message_type, is_delivered, is_seen, sender, blocked_user, created_at FROM chats WHERE group_code = '${data.group}' AND deleted_by != ${user_id} AND message_type != 'CLEARED' ORDER BY id ASC`;

            // 'BLOCKED_MESSAGE'
            if (data.pagination) {
                page = (data.page) ? +data.page : 1;
                limit = (data.limit) ? +data.limit : 10;
                offset = (page - 1) * limit;
                // offset = +data.total_fetched;
                query += ` LIMIT ${offset}, ${limit}`;
            }

            showInLog(query);

            let total_message_qry = `SELECT COUNT(*) AS total_message from chats WHERE group_code = '${data.group}'`;
            con.query(total_message_qry, function (err, result) {
                if (err) {
                    return reject(err);
                }
                let total_message = result[0]['total_message'];
                con.query(query, function (err, result) {
                    if (err) {
                        return reject(err);
                    }

                    let update_seen_status_qry = `UPDATE chats SET is_seen = 1, is_delivered = 1, updated_at = CURRENT_TIMESTAMP WHERE receiver = ${user_id} and group_code = '${data.group}' and (is_seen = 0 OR is_delivered = 0)`;
                    con.query(update_seen_status_qry, function (err, result) {
                        if (err) {
                            return reject(err);
                        }
                    });
                    let blocked_by = 0;
                    let block_state = 0;
                    let report_state = 0;

                    let block_data_qry = `SELECT * from block_users WHERE group_code = '${data.group}' AND blocked_by = ${user_id}`;
                    con.query(block_data_qry, function (err, block_result) {
                        if (err) {
                            return reject(err);
                        } else {

                            if (block_result.length > 0) {

                                if (block_result[0].blocked_by == user_id) {
                                    blocked_by = user_id;
                                    block_state = 1;
                                } else {
                                    blocked_by = block_result[0].blocked_by;
                                    block_state = 1;
                                }
                            }

                            let report_data_qry = `Select count(*) as record_exist from report_users WHERE group_code = '${data.group}' AND  reporter_id = ${user_id}`;
                            showInLog('report_data_qry');
                            showInLog(report_data_qry);
                            let report_qry = con.query(report_data_qry, function (err, report_result) {
                                if (err) {
                                    return reject(err);
                                } else {
                                    if (report_result[0].record_exist > 0) {
                                        showInLog('you reported user');
                                        report_state = 1;
                                        showInLog(report_state);
                                    } else {
                                        showInLog('you dont reported user');
                                        report_state = 0;
                                    }
                                    data_status = 1;
                                }

                                let res_data = {
                                    status: true,
                                    message: 'Chat list successfully fetched',
                                    data: result,
                                    total_message: total_message,
                                    pagination: data.pagination,
                                    total_page: Math.ceil(total_message / limit),
                                    current_page: page,
                                    block_by: parseInt(blocked_by),
                                    block_status: block_state,
                                    report_status: report_state,
                                    group: data.group,
                                }

                                showInLog(res_data);
                                return resolve(res_data);
                            });
                        }
                    });
                });
            });
        });
    });

}

//---------------- Check if user is block or not ------------
function checkIfBlock(user_id, data) {
    return new Promise((resolve, reject) => {
        let block_exist_qry = `SELECT * FROM block_users WHERE group_code = '${data.group}' AND blocked_to = ${user_id}`;
        con.query(block_exist_qry, function (err, result) {
            if (err) {
                return reject(err);
            } else {

                if (result.length > 0) {

                    if (result[0].blocked_to == user_id) {

                        var responseData = {
                            status: false,
                            message: 'Unable to send message, You are blocked by this user.',
                            data: 'YOU_ARE_BLOCKED'

                        };
                        showInLog(responseData);
                        resolve(responseData);

                    } else {
                        var responseData = {
                            status: false,
                            message: 'You blocked this user, Please unblock it first.',
                            data: {}
                        };
                        showInLog(responseData);
                        resolve(responseData);
                    }

                } else {

                    var responseData = {
                        status: true,
                        message: 'You can text',
                        data: {}
                    };
                    showInLog(responseData);
                    resolve(responseData);
                }
            }
        })
    });
}

//------------------ Logging -------------------
function showInLog(logs) {
    console.log(logs)
    // for (let index = 0; index < arguments.length; index++) {
    //     console.log(arguments[index]);
    // }
}


//send notification
async function initiatingNotification(other_user_id, msg, action, extra_data = '') {


    if (Array.isArray(other_user_id)) {

        let user_id = await other_user_id.join(',');

        var getDeviceTokenQry = `SELECT device_token FROM user_devices WHERE user_id IN (SELECT id FROM users WHERE notification_status = 1) AND user_id IN (${user_id}) AND device_token IS NOT NULL AND device_token <> ' '`;

    } else {

        var getDeviceTokenQry = `SELECT device_token FROM user_devices WHERE user_id IN (SELECT id FROM users WHERE notification_status = 1) AND user_id = ${other_user_id} AND device_token IS NOT NULL AND device_token <> ' '`;

    }

    showInLog(getDeviceTokenQry);
    con.query(getDeviceTokenQry, async function (err, result) {
        if (err) {
            showInLog('error when getting device token to send notification');
            showInLog(err);
            // return reject(err);
        }

        if (result !== undefined && result.length > 0) {
            let device = await result.map((data) => data.device_token);
            showInLog('Sending notification');
            showInLog(device)
            sendNotification(device, msg, action, extra_data);
        }

    });
}



//firebase send notification
var sendNotification = function (device, message, action, extra_data = '') {

    if (extra_data != '') {
        extra_data.type = action;
    }

    var notification_extras = {
        type: action,
        extras: extra_data
    }

    // Convert all values in notification_extras to strings
    var data = {};
    for (let key in notification_extras) {
        if (typeof notification_extras[key] === 'string' || notification_extras[key] instanceof String) {
            data[key] = notification_extras[key];
        } else {
            data[key] = JSON.stringify(notification_extras[key]);
        }
    }

    var payload = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
        tokens: Array.isArray(device) ? device : [device],
        notification: {
            title: app_name,
            body: message
        },
        data: data
    }


    fcm.sendEachForMulticast(payload)
        .then((response) => {
            showInLog("Notification successfully sent with response: ", response);
        })
        .catch((err) => {
            showInLog(err);
            showInLog("Something has gone wrong while sending notification!");
        });
}
//---------------------------- Start listening on this port ---------------------------------
http.listen(port, () => showInLog(`Listening on port: ${port}`));
