require('dotenv').config();
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http, {pingInterval: 5000, pingTimeout: 3000, cookie: false});
var request = require('request');
var mysql = require('mysql');
var forEach = require('async-foreach').forEach;
const fs = require('fs');
var async = require('async');
const {base64encode, base64decode} = require('nodejs-base64');
const Promise = require('promise');
var dateTime = require('node-datetime');
var bodyParser = require('body-parser')
var FCM = require('fcm-node');
var cors = require('cors');
var expirationTimeInSeconds =3600;
const port = process.env.PORT;  // Socket Port
const baseUrl = process.env.BASE_URL;
const appUrl = process.env.APP_URL; 
var basepath = process.env.BASE_URL;
var mainBaseurl = process.env.MAIN_BASE_URL;
var sockets = {};
var onlineUser = [];

http.listen(port, function () {
    console.log('listening on port: ' + port);
});

 app.use( bodyParser.json() );       // to support JSON-encoded bodies
 app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
     extended: false
 }));

 var con = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB,
    charset: "UTF8MB4_GENERAL_CI"
});

 app.get('/test',function(req,res){
    res.sendFile(__dirname+'/chat.html');
});

 app.get('/test2',function(req,res){
    res.sendFile(__dirname+'/chat2.html');
});

 app.get('/test3',function(req,res){
    res.sendFile(__dirname+'/chat3.html');
});


 con.connect(function (err) {
    if (err)
        throw err;
    console.log("Connected Successfully!");
});

 io.on('connection', function (socket) {
    var device_id = socket.handshake.query.device_id;
    var user_id = socket.handshake.query.user_id;

    con.query(`UPDATE users SET is_online=1 where id=${socket.handshake.query.user_id}`,function(err,res){
        if(err)
            console.log(err);
    });

    if (onlineUser.indexOf(user_id) === -1) {
        onlineUser.push(user_id);
    }
    console.log("onlineUser", onlineUser);
    var uid = parseInt(socket.handshake.query.user_id);
    if (!sockets[uid]) {
        sockets[uid] = [];
    } 
    sockets[uid].push(socket);  
/*--------------- socket.on ---------------------------*/
    socket.on('disconnect', function (err) {
        var user_id = socket.handshake.query.user_id;
        console.log("user_diconnected", user_id);
        console.log(err);
        for (var data in sockets[user_id]) {
            if (socket.id == sockets[user_id][data].id) {
                sockets[user_id].splice(data, 1);
            }
        }
        if (onlineUser.indexOf(user_id) != -1) {
            onlineUser.splice(onlineUser.indexOf(user_id),1);
            console.log("disconnect user",user_id);
            console.log("onlineUser",onlineUser);
        }
        con.query(`UPDATE users SET is_online=0 where id=${user_id}`,function(err,res){
            if(err)
                console.log(err);
        });

    });

    socket.on('send_message',async function(data,cb){
        console.log("data-------------->",data); 
        var dt = dateTime.create();
        var datetime = dt.format('Y-m-d H:M:S'); 
        var other_user_id = data.other_user_id;
        var user_id = data.user_id;
        var type = data.type;
        var message = data.message;
        var message_type = data.message_type;
        var other_data = data.other_data;
        var thumb_image = (data.thumb && data.thumb != '')?"'"+data.thumb+"'":null; 
        var latitude = (data.latitude && data.latitude != '')?"'"+data.latitude+"'":null;
        var longitude = (data.longitude && data.longitude != '')?"'"+data.longitude+"'":null;
        var conversation_id = await getConversationId(data);
        var other_is_blocked = await getUserBlockedMe(data.user_id,data.other_user_id);
        if (type=='GROUP') {
            var groupMembers = await getGroupMembers(other_user_id);
        }
        if (other_is_blocked==1) { 
            var delFor = other_user_id;
        }else{
            var delFor = 0;
        }
        var userData = await getUserOrGroupData(other_user_id,user_id,type);

        var sqCon = `update conversations set deleted_for=${delFor} where id=${conversation_id}`;
        con.query(sqCon,function(err,res){
            if(err){
                console.log('get-chats-new =========>',err);
            }
        });

        try {
            var msg_sql = "INSERT INTO `chats` (conversation_id,user_id,other_user_id,type,message_type,message,thumb,is_delivered,is_read,deleted_for,created_at,updated_at) VALUES (" + conversation_id + "," + user_id + "," + other_user_id + ",'" + type + "','" + message_type + "','" + message + "'," + thumb_image + "," +0+ ","+0+"," + delFor + ",'" + datetime + "','" + datetime + "')";
            console.log('msg_sql----',msg_sqlc);
            con.query(msg_sql, function (err, result) {
                if (err){
                    console.log('err----->',err);
                }else {
                    var insertId =result.insertId;
                    var msg_sql1 = "SELECT * FROM `chats` where id="+insertId;
                    con.query(msg_sql1, function (errr, chat) {
                        if (err){
                            console.log('err----->',errr);
                        }else{
                            chat[0].other_user_data = userData;
                            if (type=='SINGLE') {
                                /*------- SINGLE msg----------------*/  
                                if (other_is_blocked!=1) {
                                    sendEvent(other_user_id,'receive_message',{status:'true',message:"New Message Received",data:chat[0]});
                                }
                                /*------- SINGLE msg----------------*/
                            } else{
                                /*----group msg---*/
                                console.log('groupMembers---->',groupMembers);
                                groupMembers.forEach(rowDataPacket => {
                                    var usId = rowDataPacket.user_id;
                                    if (user_id!=usId) {
                                        sendEvent(usId,'receive_message',{status:'true',message:"New Message Received",data:chat[0]});
                                        var is_read =0;
                                    }else{
                                        var is_read =1;
                                    }
                                    var insert_sql11 = "INSERT INTO group_message_read_status (group_id, group_member_id,chat_id,is_read,sent_at,delivered_at,read_at) VALUES (" + other_user_id + ", " + usId + "," + insertId + "," + is_read + ",'" + datetime + "','" + datetime + "','" + datetime + "')";
                                    console.log('insert_sql1',insert_sql11);
                                    con.query(insert_sql11, function (err11) {
                                        if (err11) {
                                            console.log('err----->',err11);
                                        }
                                    });
                                });
                                /*----end group msg ---*/
                            }
                            cb({status:true,message:'Message sent Successfully',data:chat[0]});
                        }
                    });  
                }
            });
        }catch(error) {
            var ermsg = error.message;
            var lineNumber=await errorLineNumber(error.stack,error.message,user_id);
            ermsg =ermsg.replace(/'/g, "")+" lineNumber "+lineNumber;
            cb({status:false,message:ermsg,data:[]});
        }
    });


socket.on('getConversationList',async function(data,cb){
    console.log("data",data); 
    var user_id = data.user_id;
    var search = data.search;
    try {
        var sql = "SELECT conversations.*, `groups`.release_date,users.name, ";
        sql += "(SELECT count(user_reports.id) FROM user_reports WHERE user_reports.user_id = conversations.user_id AND user_reports.other_user_id = conversations.other_user_id AND user_reports.type = conversations.type) AS is_reported, ";

        sql += "CASE ";
        sql += "WHEN conversations.type = 'SINGLE' THEN (SELECT users.name FROM users WHERE users.id = CASE WHEN conversations.user_id = " + user_id + " THEN conversations.other_user_id ELSE conversations.user_id END) ";
        sql += "WHEN conversations.type = 'GROUP' THEN `groups`.group_name ";
        sql += "END AS other_user_name, ";

        // Count unread messages
        sql += "CASE ";
        sql += "WHEN conversations.type = 'SINGLE' THEN (SELECT COUNT(*) FROM chats WHERE type = 'SINGLE' AND other_user_id = " + user_id + " AND conversation_id = conversations.id AND is_read = 0) ";
        sql += "WHEN conversations.type = 'GROUP' THEN (SELECT COUNT(*) FROM group_message_read_status WHERE group_member_id = " + user_id + " AND group_id = conversations.other_user_id AND is_read = 0) ";
        sql += "END AS message_unread_count, ";

        // Get the profile picture based on the conversation type
        sql += "CASE ";
        sql += "WHEN conversations.type = 'SINGLE' THEN (SELECT users.profile_picture FROM users WHERE users.id = CASE WHEN conversations.user_id = " + user_id + " THEN conversations.other_user_id ELSE conversations.user_id END) ";
        sql += "WHEN conversations.type = 'GROUP' THEN `groups`.image ";
        sql += "END AS other_user_image, ";

        // Determine the other user ID based on the conversation type
        sql += "CASE ";
        sql += "WHEN conversations.type = 'SINGLE' THEN CASE WHEN conversations.user_id = " + user_id + " THEN conversations.other_user_id ELSE conversations.user_id END ";
        sql += "WHEN conversations.type = 'GROUP' THEN `groups`.id ";
        sql += "END AS other_user_id, ";

        // Check if the user is blocked by the other user
        sql += "(SELECT COUNT(*) FROM user_block WHERE user_block.other_id = " + user_id + " AND user_block.user_id = CASE ";
        sql += "WHEN conversations.user_id = " + user_id + " THEN conversations.other_user_id ";
        sql += "WHEN conversations.other_user_id = " + user_id + " THEN conversations.user_id ";
        sql += "END) AS is_blocked, ";

        // Check if the user has blocked the other user
        sql += "(SELECT COUNT(*) FROM user_block WHERE user_block.user_id = " + user_id + " AND (user_block.other_id = CASE ";
        sql += "WHEN conversations.user_id = " + user_id + " THEN conversations.other_user_id ";
        sql += "WHEN conversations.other_user_id = " + user_id + " THEN conversations.user_id ";
        sql += "END)) AS is_blocked_by_me ";

        sql += "FROM conversations ";
        sql += "LEFT JOIN users ON conversations.type = 'SINGLE' AND (conversations.user_id = " + user_id + " AND conversations.other_user_id = users.id OR conversations.other_user_id = " + user_id + " AND conversations.user_id = users.id) ";
        sql += "LEFT JOIN `groups` ON conversations.type = 'GROUP' AND conversations.other_user_id = `groups`.id ";
        sql += "WHERE ";
        sql += "(conversations.type = 'SINGLE' AND (conversations.user_id = " + user_id + " OR conversations.other_user_id = " + user_id + ")) ";
        sql += "OR (conversations.type = 'GROUP' AND conversations.other_user_id IN (SELECT group_id FROM group_members WHERE user_id = " + user_id + ")) ";
        if (data.search && data.search.trim() !== '') {
            sql += " HAVING other_user_name LIKE '%" + data.search + "%' ";
        }
        sql += "ORDER BY conversations.updated_at DESC ";
        con.query(sql,async function(err,res){
            if(err){
                console.log(err);
                await errorLineNumber(err.stack,err.message,user_id);
                return cb({status:'false',message:err.message,data:[]}); 
            }else{
                cb({status:'true',message:"get Conversation List",data:res}); 
            } 
        });

    }catch(error) {
            var ermsg = error.message;
            await errorLineNumber(error.stack,error.message,user_id);
            cb({status:false,message:ermsg,data:[]});
    }

});


socket.on('delete-chat',async function(data,cb){ 
    var user_id = data.user_id;
    var other_user_id = data.other_user_id;
    console.log('delete-chat  data------------------>',data);
    var convID = await getConversationFromUserOtherUser(user_id,other_user_id);
    var conversation_id = (data.conversation_id && data.conversation_id != '')?"'"+data.conversation_id+"'":convID;
    con.query(`update conversations set deleted_for=${user_id} where id=${conversation_id}  and deleted_for=0`,function(err,res){
        if(err){
         console.log('get-chats-new =========>',err);
         }
     });

    con.query(`update conversations set deleted_for=-1 where id=${conversation_id}  and deleted_for=${other_user_id}`,function(err,res){
        if(err){
         console.log('get-chats-new =========>',err);
         }
     });

    con.query(`update chats set deleted_for=${user_id} where conversation_id=${conversation_id}  and deleted_for=0`,function(err,res){
        if(err){
         console.log('get-chats-new =========>',err);
         }
     });

    con.query(`DELETE FROM chats WHERE conversation_id=${conversation_id}  and deleted_for=${other_user_id}`,function(err,res){
        if(err){
         console.log('get-chats-new =========>',err);
         }
     });

    con.query(`SELECT id FROM conversations WHERE deleted_for=-1`,function(err,res1){
        if(err){
         console.log('get-chats-new =========>',err);
         }

         if (res1.length > 0) {
            res1.forEach(function(chat) {
                console.log(chat.id);
                con.query(`DELETE FROM chats WHERE conversation_id=${chat.id}`,function(err,res){
                    if(err){
                     console.log('get-chats-new =========>',err);
                     }
                 });
                con.query(`DELETE FROM conversations WHERE id=${chat.id}`,function(err,res){
                    if(err){
                     console.log('get-chats-new =========>',err);
                    }
                 });

            });
        }
    });
    cb({status:'true',message:"Chat clear successfully",data:[]});

});



socket.on('getNoticficationCount',async function(data,cb){
    console.log("data",data); 
    var group_id = data.group_id;
    var user_id = data.user_id;
    var sql = "SELECT count(id) as message_count FROM group_message_read_status where is_read=0 and group_id="+group_id+" and group_member_id="+user_id;
    con.query(sql,function(err,res){
        if(err){
            console.log(err);
            return cb({status:'false',message:err.message,data:[]}); 
        }else{
            if (res.length>0) {
                var da = res[0];
            }else{
                var da = {message_count:0};
            }
            console.log('da------->',da);
            cb({status:'true',message:"get Noticfication Count Successfully",data:da}); 
        } 
    });
});

socket.on('get-online-user',async function(data,cb){
    console.log("data",data); 
    var user_id = data.user_id;
    var search = data.search;

    console.log("mainBaseurl-------------",mainBaseurl); 
    var sql = "SELECT users.*, ";
    sql += "(SELECT COUNT(user_reports.id) FROM user_reports WHERE user_reports.user_id = " + user_id + " AND user_reports.other_user_id = users.id) as is_reported, ";
    sql += "(SELECT conversations.id FROM conversations WHERE type='SINGLE' AND " +
    "((conversations.user_id = users.id AND conversations.other_user_id = " + user_id + ") " +
    "OR (conversations.user_id = " + user_id + " AND conversations.other_user_id = users.id)) " +
    "LIMIT 1) as conversation_id, ";
    sql += "CONCAT('" + mainBaseurl + "', users.profile_picture) as profile_picture, ";
    sql += "(SELECT COUNT(*) FROM user_block WHERE user_block.user_id = users.id AND user_block.other_id = " + user_id + ") as is_blocked, ";

    sql += "(SELECT COUNT(*) FROM user_block WHERE user_block.user_id = " + user_id + " AND user_block.other_id = users.id) as is_blocked_by_me ";
    sql += "FROM users WHERE is_online = 1 AND id != " + user_id;

    if (search && search.trim() !== '' && search !== 'undefined') {
        sql += " AND LOWER(`users`.name) LIKE '%" + search.toLowerCase() + "%' ";
    }

    sql += " ORDER BY name ASC ";

    console.log('sql',sql);
    con.query(sql,function(err,res){
        if(err){
            console.log(err);
                //return cb({status:'false',message:err.message,data:[]}); 
        }else{
            console.log('da------->',res);
            cb({status:'true',message:"get online users Successfully",data:res}); 
        } 
    });
});

socket.on('seenGroupMessage',async function(data,cb){
    console.log("data",data); 
    var group_id = data.group_id;
    var user_id = data.user_id;
    var sql = "UPDATE group_message_read_status set is_read=1 where is_read=0 and group_id="+group_id+" and group_member_id="+user_id;
    con.query(sql,function(err,res){
        if(err){
            console.log(err);
            return cb({status:'false',message:err.message,data:[]}); 
        }else{
            cb({status:'true',message:"get Noticfication status updated Successfully",data:res}); 
        } 
    });
});


socket.on('read-message',async function(data,cb){ 
    var ids = data.ids;
    console.log('read-message--------------------------------------------------->',ids);
        //if(ids && ids.length>0){
    con.query(`UPDATE chats set is_read=1 where id=${ids}`,function(err,result){
        if(err)
            console.log(err); 
        console.log('read-message--------------------------------------------------->');
        cb({status:'true',message:"read-message",data:[]});
    });
        //}
});

socket.on('clear_group_chat', function (data,cb) {
    var user_id = data.user_id;
    var other_user_id = data.other_user_id;
    var last_msg_id = data.last_msg_id;
    var dt = dateTime.create();
    var datetime = dt.format('Y-m-d H:M:S');

    var member_sql1 = "DELETE FROM `group_chat_clear` WHERE user_id='"+user_id+"' and group_id='"+other_user_id+"'";
    console.log('member_sql1----->',member_sql1);
    con.query(member_sql1, function (err, result1) {});

    var member_sql = "INSERT INTO `group_chat_clear` (user_id,group_id,msg_id,created_at,updated_at) VALUES ('"+user_id+"','"+other_user_id+"','"+last_msg_id+"','" + datetime + "','" + datetime + "')";
    console.log('member_sql',member_sql);
    con.query(member_sql, function (err, result) {
        if (err)
            throw err;
        else {
            cb({status:true,message:"group chat clear successfully",data:result});  
        }
    });

});


socket.on('getchats',async function(data,cb){ 
    var conversation_id = (data.conversation_id && data.conversation_id != '')?"'"+data.conversation_id+"'":0;
    var user_id = data.user_id;
    var reportedUser =0;
    var message_id =0;
    var joinid =0;
    if (conversation_id!=0) {
        console.log('conversation_id=====================>',conversation_id);
        var updateMessageIsRead = await updMessageIsRead(conversation_id,user_id);
        var conversationData = await getConversationData(conversation_id);
        var reportedUser = await getreportedUser(conversationData.other_user_id,user_id,conversationData.type);
        if (conversationData.type=='GROUP') {
            var message_id = await getClearChatMsgId(user_id,conversationData.other_user_id);
            var joinid = await getJoinedId(user_id,conversationData.other_user_id);
        }else{
            var message_id =0;
            var joinid =0;
        }
    }
    var select_sql = "SELECT chats.*, ";
    select_sql += "CASE WHEN chats.type = 'GROUP' THEN u1.id ELSE u2.id END as users_id, ";
    select_sql += "CASE WHEN chats.type = 'GROUP' THEN u1.name ELSE u2.name END as user_name, ";
    select_sql += "CASE WHEN chats.type = 'GROUP' THEN u1.profile_picture ELSE u2.profile_picture END as profile_picture, ";
    select_sql += "`groups`.id as groups_id, `groups`.group_name ";
    select_sql += "FROM chats ";
    select_sql += "LEFT JOIN users u1 ON chats.type = 'GROUP' AND chats.user_id = u1.id ";
    select_sql += "LEFT JOIN users u2 ON chats.type = 'SINGLE' AND chats.other_user_id = u2.id ";
    select_sql += "LEFT JOIN `groups` ON chats.type = 'GROUP' AND chats.other_user_id = `groups`.id ";
    select_sql += "WHERE conversation_id = " + conversation_id;
    select_sql += " AND chats.id > " + message_id;
    if (conversation_id!=0) {
        if (conversationData.type=='GROUP') {
          select_sql += " AND chats.id >="+joinid;  
      }
  }
  if (typeof data.last_id != 'undefined' && data.last_id > 0) {
    if (typeof data.type != 'undefined' && data.type == "before") {
        select_sql += " AND chats.id < " + data.last_id;
    } else if (typeof data.type != 'undefined' && data.type == "after") {
        select_sql += " AND chats.id > " + data.last_id;
    }
}
select_sql += " ORDER BY chats.id DESC LIMIT " + data.limit;
con.query(select_sql,function(err,data){
    if(err){ console.log('err----->',err); }else{
        if (data.length>0) {
            console.log('data--------->',data);
        }
        var firstId =0;
        return cb({status:'true',message:"Get chat Successfully",data:data,first_id:firstId,is_reported:reportedUser});
    }
});
});

socket.on('user_block_unblock', function (data,cb) {
    con.query("SELECT count(*) as record_exist FROM `user_block` WHERE user_id=" + data.user_id + "  AND other_id = " + data.other_user_id, function (err, result) {
        if (err) {
            console.log("err ",err);
        } else {
            if (result[0].record_exist > 0) {
                con.query("DELETE FROM `user_block` WHERE user_id = " + data.user_id + " AND other_id = " + data.other_user_id, function (delete_err) {
                    if (err) {
                        console.log("err ",err);
                    } else {
                        var responseData = {
                            status: true,
                            msg: "User unblocked successfully.",
                            user_id: data.user_id,
                            other_user_id: data.other_user_id,
                            block_status: 0
                        };
                        console.log("User unblocked successfully.",responseData);

                        var usId = data.other_user_id;
                        sendEvent(usId,'user_unblocked',responseData);
                        cb({status:true,message:"User unblocked successfully.",data:responseData});
                    }
                });
            } else {
                var dt = dateTime.create();
                var datetime = dt.format('Y-m-d H:M:S');

                con.query("INSERT INTO `user_block` (`user_id`, `other_id`,`created_at`,`updated_at`) VALUES (" + data.user_id + ", " + data.other_user_id + ",'" + datetime + "','" + datetime + "')", function (insert_err) {
                    if (err) {
                        console.log("err ",err);
                    } else {
                        var responseData = {
                            status: true,
                            msg: "User blocked successfully.",
                            user_id: data.user_id,
                            other_user_id: data.other_user_id,
                            block_status: 1
                        };
                        console.log("User blocked successfully.",responseData);
                        var usId = data.other_user_id;
                        sendEvent(usId,'user_blocked',responseData);
                        cb({status:true,message:"User blocked successfully.",data:responseData});
                    }
                });
            }
        }
    });
});

/*--------------- socket .on end ---------------------------*/
});

function sendEvent(user_id,event,data){ 
    return new Promise((resolve,reject)=>{
        for (var index in sockets[user_id]) {
            console.log("event",event);
            sockets[user_id][index].emit(event, data);
        }
        resolve();
    })
}

/*---------new -----*/


function getreportedUser(other_user_id,user_id,type){
    console.log('getreportedUser--------->',other_user_id);
    return new Promise((resolve,reject)=>{
        var sql = "SELECT * FROM `user_reports` WHERE user_id="+user_id+" AND other_user_id="+other_user_id+" AND type='"+type+"'";
        console.log('sql',sql);
        con.query(sql,function(err,res){
            if (err) { console.log('err--->',err); }

            if (res.length>0) {
                var de = '1';
                resolve(de);
            }else{
                var de = '0';
                resolve(de);
            }
        });
        
    });
}

function getConversationData(conversation_id){
    console.log('updMessageIsRead conversation_id--------->',conversation_id);
    return new Promise((resolve,reject)=>{
        var sql = "SELECT * FROM `conversations` WHERE id="+conversation_id;
        console.log('sql',sql);
        con.query(sql,function(err,res){
            if (err) { console.log('err--->',err); }

            if (res.length>0) {
                resolve(res[0]);
            }else{
                console.log('getConversationData data not found--->');
                resolve(1);
            }
        });
        
    });
}

function updMessageIsRead(conversation_id,user_id){
    console.log('updMessageIsRead conversation_id--------->',conversation_id);
    return new Promise((resolve,reject)=>{
        var sql1 = "UPDATE group_message_read_status SET is_read=1 WHERE is_read=0 AND group_member_id="+user_id+" AND chat_id IN (SELECT id FROM chats where type='GROUP' And conversation_id="+conversation_id+")";
        console.log('sql1',sql1);
        con.query(sql1,function(err,res){});

        var sql = "UPDATE chats SET is_read=1 WHERE is_read=0 AND other_user_id="+user_id+" AND type='SINGLE' AND conversation_id="+conversation_id;
        console.log('sql',sql);
        con.query(sql,function(err,res){});
        resolve(1);
    });
}

function getUserOrGroupData(other_user_id,user_id,type){
    return new Promise((resolve,reject)=>{
        if (type=='GROUP') {
            var sl = 'SELECT * FROM `groups` WHERE id='+other_user_id+' LIMIT 1';
            console.log('sl================>',sl);
            con.query(sl,function(err,res){ 
                if(err){
                    console.log(err)
                    resolve(-1); 
                }else{
                    console.log('res--------->',res);
                    resolve(res);
                } 
            });
        }else{
            var sl = 'SELECT * FROM `users` WHERE id='+user_id+' LIMIT 1';
            console.log('sl================>',sl);
            con.query(sl,function(err,res){ 
                if(err){
                    console.log(err)
                    resolve(-1); 
                }else{
                    console.log('res--------->',res);
                    resolve(res);
                } 
            });
        }
    });
}

function getGroupMembers(group_id){
    console.log('group_id--------->',group_id);
    return new Promise((resolve,reject)=>{
        var dt = dateTime.create();
        var created_at =dt.format('Y-m-d H:M:S');
        con.query(`SELECT user_id FROM group_members where group_id=${group_id}`,function(err,res){ 
            if(err){
                console.log(err)
                resolve(-1); 
            }else{
                console.log('res--------->',res);
                resolve(res);
            } 
        });
    });
}


function getJoinedId(user_id,group_id) {
    return new Promise(function (resolve, reject) {
        var select_sql = "SELECT * FROM `chats` WHERE user_id='"+user_id+"' and other_user_id='"+group_id+"' and message='JOIN_GROUP' order by id DESC limit 1";
        //var select_sql = "SELECT * FROM `group_members` WHERE user_id='"+user_id+"' and group_id ='"+group_id+"' order by id DESC limit 1";
        console.log("select_sql==", select_sql);
        con.query(select_sql, function (err, users) {
            if (err)
                reject(err);

            console.log('getJoinedId full data------',users)
            if (users.length > 0) {
                console.log("getJoinedId--data-==", users[0].id);
                resolve(users[0].id);
            }else{
                resolve(0);
            }
        });
    });
}

function getClearChatMsgId(user_id,group_id) {
    return new Promise(function (resolve, reject) {
        //var user_sql = "SELECT status FROM `users` WHERE id=" + user_id + " LIMIT 1";
        var select_sql = "SELECT * FROM `group_chat_clear` WHERE user_id='"+user_id+"' and group_id='"+group_id+"' order by id DESC limit 1";
        console.log("select_sql==", select_sql);
        con.query(select_sql, function (err, users) {
            if (err)
                reject(err);
            if (users.length > 0) {
                console.log("group_chat_clear---==", users[0].msg_id);
                resolve(users[0].msg_id);
            }else{
                resolve(0);
            }
        });
    });
}

function getConversationFromUserOtherUser(user_id,other_user_id) {
    return new Promise(function (resolve, reject) {
        var select_sql = "SELECT * FROM `conversations` WHERE ((user_id='"+user_id+"' and other_user_id='"+other_user_id+"') OR (user_id='"+other_user_id+"' and other_user_id='"+user_id+"') ) AND type='SINGLE' order by id DESC limit 1";
        console.log("select_sql==", select_sql);
        con.query(select_sql, function (err, data) {
            if (err)
                reject(err);
            if (data.length > 0) {
                console.log("getConversationFromUserOtherUser ---==", data);
                console.log("getConversationFromUserOtherUser ---==", data[0].id);
                resolve(data[0].id);
            }else{
                resolve(0);
            }
        });
    });
}


function getUserBlockedMe(user_id,other_user_id) {
    return new Promise(function (resolve, reject) {
        //getConversationFromUserOtherUser(user_id,other_user_id)
        var select_sql = "SELECT * FROM `user_block` WHERE user_id='"+other_user_id+"' and other_id='"+user_id+"' order by id DESC limit 1";
        console.log("select_sql==", select_sql);
        con.query(select_sql, function (err, data) {
            if (err)
                reject(err);
            if (data.length > 0) {
                resolve(1);
            }else{
                resolve(0);
            }
        });
    });
}



function getConversationId(data){
    // console.log(group_id);

    return new Promise((resolve,reject)=>{
        var dt = dateTime.create();
        var created_at =dt.format('Y-m-d H:M:S');
        var whereCase = "(((user_id = " + data.user_id + " AND other_user_id = " + data.other_user_id + 
        ") OR (user_id = " + data.other_user_id + " AND other_user_id = " + data.user_id + 
        ")) AND type = 'SINGLE') OR (other_user_id = " + data.other_user_id + " AND type = 'GROUP')";

        var select_sql = "SELECT id FROM `conversations` WHERE "+whereCase;
        console.log('select_sql---------',select_sql);
        con.query(`${select_sql}`,function(err,conversation){ 
            if(err){
                console.log(err)
                resolve(-1); 
            }else{
                console.log('conversation------',conversation);
                if(conversation[0]){ 
                    con.query(`UPDATE conversations SET user_id=${data.user_id},other_user_id=${data.other_user_id}, message_type='${data.message_type}', message="${data.message}", updated_at='${created_at}' where id=${conversation[0].id}`,function(err,res){ 
                        if(err){
                            console.log(err);
                            resolve(-1); 
                        }else{ 
                            resolve(conversation[0].id);
                        }  
                    });
                }else{ 
                    con.query(`INSERT INTO conversations (user_id,other_user_id,type,message_type,message,created_at,updated_at) VALUES (${data.user_id},${data.other_user_id},'${data.type}','${data.message_type}','${data.message}','${created_at}','${created_at}')`,function(err,res){
                        if(err){ 
                            console.log(err);
                            resolve(-1);   
                        }else{
                            resolve(res.insertId);
                        } 
                    })
                }
            } 
        });
    });
}

function socketErrorCatchInApiLog(user_id,path,error){
    return new Promise((resolve,reject)=>{
        var dt = dateTime.create();
        var created_at =dt.format('Y-m-d H:M:S');
        con.query(`INSERT INTO api_log (user_id,uri,request,created_at,updated_at) VALUES (${user_id},'${path}','${error}','${created_at}','${created_at}')`,function(err,res){
            if(err){ 
                console.log('err======',err);
                resolve(-1);   
            }else{
                resolve(res.insertId);
            } 
        }); 
    });
}

async function errorLineNumber(stack,ermsg,user_id){
    var stackLines = stack.split('\n');
    var lineNumber;
    for (var i = 0; i < stackLines.length; i++) {
        if (stackLines[i].includes(__filename)) {
            var lineMatch = stackLines[i].match(/:(\d+):(\d+)/);
            lineNumber = lineMatch ? lineMatch[1] : undefined;
            break;
        }
    }
    ermsg =ermsg.replace(/'/g, "")+" lineNumber "+lineNumber;
    await socketErrorCatchInApiLog(user_id,'Socket Event ----send_message',ermsg);
    return lineNumber;
}




