# Chat Integration Guide

This guide provides steps for integration of chat which include one to one chat and group chat module.

## Prerequisites

You will need the following details:
- `Android Json file for notifications`
- `Node Js installed in system`
- `PM2 installed`


# Instruction to setup:

```sh
npm install
pm2 start <file name>
```

Import the given table into the database of the respective module.

## Note
Update this chat module according to your project requirements.
