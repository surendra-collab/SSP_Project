<?php
namespace App\Lib;
use Config;
use Illuminate\Support\Facades\Crypt;

class Stripe
{
    public static function createCustomer($email) {
        $url = "https://api.stripe.com/v1/customers";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $stripeSecretKey = decodeBaseKey('STRIPE_SECRET_KEY_SALT','STRIPE_SECRET_KEY_VALUE');
        // $stripeSecretKey = Config::get('constants.STRIPE_SECRET_KEY');

        $headers = array(
           "Content-Type: application/x-www-form-urlencoded",
           "Authorization: Bearer ".$stripeSecretKey
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        $data = "email=$email";
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($curl);
        curl_close($curl);
        $response = json_decode($resp, true);

        return $response;

        var_dump($resp);
    }
    
    public static function createConnectAccount($user) {
        
        $stripeSecretKey = decodeBaseKey('STRIPE_SECRET_KEY_SALT','STRIPE_SECRET_KEY_VALUE');
        // $stripeSecretKey = Config::get('constants.STRIPE_SECRET_KEY');

        $stripe = new \Stripe\StripeClient($stripeSecretKey);

        if(!$user->stripe_connect_id)
        {
            $connect_check = $stripe->accounts->create([
              'country' => 'US',
              'type' => 'express',
              'capabilities' => [
                'card_payments' => ['requested' => true],
                'transfers' => ['requested' => true],
              ],
              'business_type' => 'individual',
            ]);
            $user->stripe_connect_id = $connect_check['id'];
            $user->save();
        }

        $account_check_link = $stripe->accountLinks->create([
              'account' => ($user->stripe_connect_id) ? $user->stripe_connect_id : $connect_check['id'],
              'refresh_url' => base_url().'/api/v1/connect-account-url/'.Crypt::encrypt($user->id),
              'return_url' => base_url().'/connect-account-response/'.$user->stripe_connect_id,
              'type' => 'account_onboarding',
        ]);

        return $account_check_link->url;
    }

    public static function paymentIntent($user,$vendor,$amount,$transferamount,$order,$uniqid){
        try{

            $stripeSecretKey = decodeBaseKey('STRIPE_SECRET_KEY_SALT','STRIPE_SECRET_KEY_VALUE');
            // $stripeSecretKey = Config::get('constants.STRIPE_SECRET_KEY');

            $customer_stripe_id = $user->customer_stripe_id;
            $client_public = \Stripe\Stripe::setApiKey($stripeSecretKey);

            $ephemeralKey = \Stripe\EphemeralKey::create([
                  'customer' => $customer_stripe_id,
                ],[
                  'stripe_version' => '2022-08-01',
            ]); 
                   
            $data['amount']         = $amount;
            $data['customer_id']    = $customer_stripe_id;
            $data['ephemeral_Keys'] = $ephemeralKey->id;
            $data['metadata']       = [
                'type'       => 'INITIAL_PAYMENT',
                'user_id'    => $user->id,
                'vendor_id'  => $vendor->id,
                'order_id'   => $order->id,
            ];

            $connectedAccountId = $owner->stripe_connect_id;
            
            $intent = Stripe::createPaymentIntent($data,$transferamount,$connectedAccountId,$customer_stripe_id,$uniqid);
           
            if ($intent['status'] == true) {
                $info['paymentIntent']    = $intent['data']['client_secret'];
                $info['paymentIntent_id'] = $intent['data']['id'];
                $info['transfer_group']   = $uniqid;
                $info['latest_charge']    = $intent['data']['latest_charge'];
                $info['ephemeralKey']     = $ephemeralKey->secret;
                $info['customer']         = $customer_stripe_id;
                $info['order_id']         = $order->id;

                $respo = ['status' => true, 'message' => 'Payment Intent Created.', 'data' => $info];

                return $respo;
            } else {
                $respo = ['status' => false, 'message' => 'Booking failed.', 'data' => null];
                return $respo;
            }
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }

    public static function createPaymentIntent($data, $transferamount,$connectedAccountId,$customer_stripe_id,$uniqid) {
        try {

            $stripeSecretKey = decodeBaseKey('STRIPE_SECRET_KEY_SALT','STRIPE_SECRET_KEY_VALUE');
            // $stripeSecretKey = Config::get('constants.STRIPE_SECRET_KEY');

            $amount = $data['amount'];
            \Stripe\Stripe::setApiKey($stripeSecretKey);
            $intent = \Stripe\PaymentIntent::create([
                'amount'        => $amount * 100,
                'currency'      => 'usd',
                'metadata'      => $data['metadata'],
                'customer'      => $customer_stripe_id,
                'on_behalf_of'  => $connectedAccountId,
                'payment_method_types' => [
                    'card'
                ],
                'transfer_data' => [
                    'destination' => $connectedAccountId, 
                    'amount'      => $transferamount * 100,
                ],
                'transfer_group' => $uniqid,
            ]);

            $respo = ['status' => true, 'message' => 'Payment Intent Created.', 'data' => $intent];
            return $respo;
        } catch (\Exception $e) {
            $respo = ['status' => false, 'message' => $e->getMessage(), 'data' => null];
            return $respo;
        }
    }

    public static function refund($transfer_id = null, $payment_intent_id = null, $refund_amount = null) {
        try {
            $stripeSecretKey = decodeBaseKey('STRIPE_SECRET_KEY_SALT','STRIPE_SECRET_KEY_VALUE');
            // $stripeSecretKey = Config::get('constants.STRIPE_SECRET_KEY');

            \Stripe\Stripe::setApiKey($stripeSecretKey);

            $refund = \Stripe\Refund::create([
                'payment_intent' => $payment_intent_id,
                'amount'         => $refund_amount * 100,
            ]);

            $merchant_refund = \Stripe\Transfer::createReversal($transfer_id);

            $response = [
                'status'  => 'true',
                'refund'  => [
                    'charge_refund'   => $refund,
                    'merchant_refund' => $merchant_refund,
                ],
                'message' => 'Charge refunded successfully.',
            ];
        } catch (\Exception $e) {
            $response = [
                'status'  => 'false', 'refund'  => [],'message' => 'Error: ' . $e->getMessage() . ' on line ' . $e->getLine(),
            ];
        }

        return $response;
    }
}