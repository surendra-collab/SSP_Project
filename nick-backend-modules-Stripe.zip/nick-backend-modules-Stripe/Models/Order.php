<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Order extends Model
{
 
    protected $fillable = [
        'user_id',
        'vendor_id',
        'total_amount',
        'transfer_amount',
        'payment_intent_id',
        'transfer_id',
        'transfer_group',
        'order_status',
        'payment_status'
    ];


    public function user(){
        return $this->hasOne(User::class, 'id','user_id');
    }

    public function vendor(){
        return $this->hasOne(User::class, 'id','vendor_id');
    }
}
