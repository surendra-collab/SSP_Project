# Stripe Implementation


# Install Stripe package:

```sh
composer require stripe/stripe-php
```


# Add these columns in user table

```sh
ALTER TABLE `users` ADD `customer_stripe_id` VARCHAR(255) NULL DEFAULT NULL AFTER `id`, ADD `stripe_connect_id` VARCHAR(255) NULL DEFAULT NULL AFTER `customer_stripe_id`, ADD `stripe_setup` TINYINT(1) NULL DEFAULT '0' AFTER `stripe_connect_id`;
```



# Generate Customer Id in Sign up and Sign in API

```php
Route::post('signup', [ApiController::class, 'signup']);
Route::post('signin', [ApiController::class, 'signin']);
```


# Connect Account Flow

## Connect Account URL API 

```php
Route::post('connect-account-url', [ApiController::class, 'connectAccountUrl']);
```

## Connect Account Response in web controllers

```php
Route::any('connect-account-response/{id?}', [StripeWebController::class, 'connectAccountResponse']);
Route::any('connect-account-status/{key?}', [StripeWebController::class, 'connectAccountStatus']);
```


## Payment Intent Flow

```php
Route::post('payment-intent', [ApiController::class, 'paymentIntent']);
Route::post('confirm-order', [ApiController::class, 'confirmOrder']);
Route::post('refund', [ApiController::class, 'refund']);
```


## Webhooks for payment response and transfer response

```php
Route::any('stripe-payment-response', [StripeWebController::class, 'stripePaymentResponse']);
Route::any('stripe-transfer-response', [StripeWebController::class, 'stripeTransferResponse']);
```

## Note
Update this module according to your project requirements.