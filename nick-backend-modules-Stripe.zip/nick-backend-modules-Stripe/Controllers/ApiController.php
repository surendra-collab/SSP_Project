<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\User;
use JWTAuth;

class ApiController extends Controller
{
    protected function signup(Request $request)
    {
        try {
                
            $usersdetails = User::where('id',$user->id)->first();

            if (empty($usersdetails->customer_stripe_id)) {
                $stripeCustomer = \App\Lib\Stripe::createCustomer($usersdetails->email);
                $usersdetails->customer_stripe_id = $stripeCustomer['id'];
                $usersdetails->save();
            }

        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }

    protected function signin(Request $request)
    {
        try {

            $usersdetails = User::where('id',$user->id)->first(); 

            if (empty($usersdetails->customer_stripe_id)) {
                $stripeCustomer = \App\Lib\Stripe::createCustomer($usersdetails->email);
                $usersdetails->customer_stripe_id = $stripeCustomer['id'];
                $usersdetails->save();
            }

        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }

    public function connectAccountUrl($user_id = NULL){
        try {
            $userId   = JWTAuth::getToken()?JWTAuth::toUser(JWTAuth::getToken())->id:NULL;

            if ($userId == NULL) {
                $userId = Crypt::decrypt($user_id);
            }

            $usersdetails = User::where('id',$userId)->first(); 

            if (!$usersdetails) {
                return response()->json(['status' => false, 'message' => 'User not found.', 'data' => (object) []]);
            } else {
                if ($usersdetails->status == 1) {
                    if($usersdetails->stripe_setup == 0){
                                
                        $stripe_connect_url =  \App\Lib\Stripe::createConnectAccount($usersdetails);

                    }else{
                        $stripe_connect_url ='';
                    }
                    $usersdetails['stripe_connect_url'] = $stripe_connect_url;

                    return response()->json(['status' => true, 'message' => 'Success.', 'data' => $usersdetails]);
                }else{
                    return response()->json(['status' => false, 'message' => 'Your account is deactivated,Please contact to admin.', 'data' => []]);

                }
            }
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }

    public function paymentIntent(Request $request)
    {
        try {
            $uniqid = uniqid('AnyRandomString', true);

            // $user   = user object that will pay;
            // $vendor = Vendor object to which we have to transfer the amount;
            // $transfer_amount = Amount payable to merchant;
            // $total_amount = Total amount of order with stripe fee and admin commission;

            $order = new Order();
            $order->user_id         = $user->id;
            $order->vendor_id       = $vendor->id;
            $order->total_amount    = $total_amount;
            $order->transfer_amount = $transfer_amount;
            $order->transfer_group  = $uniqid;
            $order->order_status    = 'pending';
            $order->payment_status  = 'pending';
            $order->save();

            $paymentIntent = Stripe::paymentIntent($user,$vendor,$total_amount,$transfer_amount,$order,$uniqid);

            if($paymentIntent['status'] == true){
                
                return response()->json(['status' => true, 'message' => 'Payement intent genrate successfully.', 'data' => $paymentIntent['data']]);
            }else{
                $order->delete();
                return response()->json(['status' => true, 'message' => 'Some error occurred please try again later.', 'data' => []]);
            }
            
            
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }

    public function refund(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'order_id' => 'required',
            ]);
            if (!validate($validator)) {
                return response_msg();
            } else {

                $order = Order::whereId($request->order_id)->where('payment_status','completed')->first();
                $transfer_id       = $order->transfer_id; 
                $payment_intent_id = $order->payment_intent_id; 
                $refund_amount     = (float)$order->total_amount;
                
                $refund = Stripe::refund($transfer_id,$payment_intent_id,$refund_amount);
                
                if ($refund['status'] == 'true') {
                    return response()->json(['status' => true, 'message' => $message, 'data' => $refund]);
                }else{
                    return response()->json(['status' => false, 'message' => "Something went wrong.", 'data' => []]);
                }
            }
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }

    public function confirmOrder(Request $request)
    {
        try{
            $validator = Validator::make($request->all(), [
                'order_id' => 'required',
            ]);
            if (!validate($validator)) {
                return response_msg();
            } else {
                $userId = JWTAuth::toUser(JWTAuth::getToken())->id;

                $order = Order::whereId($request->order_id)->where('payment_status','pending')->first();
                if ($order) {
                    $order->order_status   = "in-progress";
                    $order->payment_status = "in-progress";
                    $order->save();
                    
                    return response()->json(['status' => true, 'message' => "Order confirmed successfully.", 'data' => []]);
                }else{
                    return response()->json(['status' => true, 'message' => "Order confirmed successfully.", 'data' => []]);
                }
            }
        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => (object) []]);
        }
    }
}
