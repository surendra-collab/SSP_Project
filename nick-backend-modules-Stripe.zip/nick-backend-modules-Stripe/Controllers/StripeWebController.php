<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;

class StripeWebController extends Controller
{
    public function connectAccountResponse($id){

        $stripeSecretKey = decodeBaseKey('STRIPE_SECRET_KEY_SALT','STRIPE_SECRET_KEY_VALUE');
        // $stripeSecretKey = Config::get('constants.STRIPE_SECRET_KEY');

        $stripe = new \Stripe\StripeClient($stripeSecretKey);

        $update = $stripe->accounts->update(
            $id,
            [
                'capabilities' => [
                    'card_payments' => ['requested' => true],
                    'transfers' => ['requested' => true]
                ]
            ]
        );

        $accounts = $stripe->accounts->retrieve($id,[]);

        if ($accounts['details_submitted'] == false || $accounts['payouts_enabled'] == false || $accounts['charges_enabled'] == false || (isset($accounts['capabilities']['transfers']) && $accounts['capabilities']['transfers'] !== 'active')) {
            return redirect('connect-account-status/error');
        }

        $user = User::where('stripe_connect_id',$id)->first();

        if ($user) {
            $user->stripe_setup = 1;
            $user->save();
            return redirect('connect-account-status/success');
        }else{
            return redirect('connect-account-status/error');
        }
    }

    public function connectAccountStatus($key){
        if ($key == 'success') {
            $details = "You are all set with your stripe account, please wait while we redirect you to the app. Redirecting...";
        }else{
            $details = "Please set up the stripe account again and ensure that all information is filled accurately.";
        }
        return view('connect_account_status',compact('details'));
    }

    public function stripePaymentResponse(){
        $payload = @file_get_contents('php://input');
        if ($payload) {
            $decoded_payload = json_decode($payload, true);

            if ($decoded_payload !== null) {

                $payment_intent_id = $decoded_payload['data']['object']['id'];
                $chargeId          = $decoded_payload['data']['object']['latest_charge'];
                $orderId           = $decoded_payload['data']['object']['metadata']['order_id'];

                $order = Order::whereId($orderId)->first();

                if ($order) {
                    $order->payment_intent_id = $payment_intent_id;
                    $order->order_status      = 'confirmed';
                    $order->payment_status    = 'completed';
                    $order->save();
                }
            } else {
                \Log::error('Failed to decode Stripe webhook JSON.');
            }
        } else {
            \Log::error('No payload received from Stripe webhook.');
        }
    }

    public function stripeTransferResponse(){
        $payload = @file_get_contents('php://input');

        if ($payload) {
            $decoded_payload = json_decode($payload, true);

            if ($decoded_payload !== null) {

                $transfer_id    = $decoded_payload['data']['object']['id'];
                $transfer_group = $decoded_payload['data']['object']['transfer_group'];

                $order = Order::where('transfer_group',$transfer_group)->first();

                if ($order) {
                    $order->transfer_id = $transfer_id;
                    $order->save();
                }
            } else {
                \Log::error('Failed to decode Stripe transfer webhook JSON.');
            }
        } else {
            \Log::error('No payload received from Stripe transfer webhook.');
        }
    }
}
