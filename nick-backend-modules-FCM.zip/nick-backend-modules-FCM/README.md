# FCM Integration Guide

This guide provides steps for integrating the FCM notification.

# Install Required package:

```sh
composer require kreait/firebase-php
```

## Prerequisites

You will need the following details:
- `Android Json file`


### Step 1

After installing the package, you need to mention Helper.php in composer.json to auto-load it. Here is a sample code:


```sh
"autoload": {
        "files": [
            "app/Helpers/Helper.php"
        ]
    }
```


Then run:

```sh
composer dump-autoload
```

### Step 2(Sending Notification)

Here is a sample code to send a notification:

```php
$notification_arr = [
    'user_id' => $request->friend_id,
    'sender_id' => $userId,
    'title' => 'Match Request',
    'type' => 'MATCH_REQUEST',
    'message' => $user->user_name . ' send you a match request.',
];
Notifications::create($notification_arr);
sendNotification($notification_arr);
```

## Note
This sample code demonstrates how to use the FCM Notification. Update this module according to your project requirements.
