<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id')->nullable();
            $table->unsignedInteger('sender_id')->nullable();
            $table->integer('reference_id')->nullable();
            $table->string('title', 250)->nullable();
            $table->string('type', 100)->charset('utf8mb4')->collation('utf8mb4_0900_ai_ci')->nullable();
            $table->longText('message')->charset('utf8mb4')->collation('utf8mb4_0900_ai_ci');
            $table->tinyInteger('is_seen')->default(0)->comment('0=not seen, 1=seen');
            $table->timestamps();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });

        // Set the primary key
        Schema::table('notifications', function (Blueprint $table) {
            $table->primary('id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notifications');
    }
}
