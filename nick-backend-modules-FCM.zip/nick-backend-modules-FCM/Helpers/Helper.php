<?php 

use App\Models\UserDevice;

use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

// Send notification using firebase.
function sendNotification($data)
{
    if ($data['user_id'] != "") {

        $query = UserDevice::whereHas('user', function ($q) {
            $q->where('notification_status', 1);
        });
        if (is_array($data['user_id'])) {
            $FcmUserToken = $query->whereIn('user_id', $data['user_id'])->whereNotNull('device_token')->where('device_token', '<>', " ")->pluck('device_token')->all();
        } else {
            $FcmUserToken = $query->where('user_id', $data['user_id'])->whereNotNull('device_token')->pluck('device_token')->all();
        }

        if (!empty($FcmUserToken)) {

            $extra = $data;

            $extra = [];
            foreach ($data as $key => $value) {
                if (is_string($value)) {
                    $extra[$key] = $value;
                } else {
                    $extra[$key] = json_encode($value);
                }
            }


            $firebase = (new Factory)
                ->withServiceAccount(public_path() . '/app_android.json');

            $messaging = $firebase->createMessaging();

            $message = CloudMessage::fromArray([
                'notification' => [
                    "title" => $data['title'],
                    "body" => $data['message'],
                ],
                'data' => $extra
            ]);

            $res = $messaging->sendMulticast($message, $FcmUserToken);

            // // Process the result
            // $successful = $res->successes()->count();
            // $failed = $res->failures()->count();

            // $failures = $res->failures()->map(function ($failure) {
            //     return [
            //         'token' => $failure->target(),
            //         'error' => $failure->error()->getMessage(),
            //     ];
            // });

            // $result = json_encode([
            //     'successful' => $successful,
            //     'failed' => $failed,
            //     'failures' => $failures,
            // ]);

            // \Log::info($result);
        }
    }
}
