<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V2\PlaidApiController;
use App\Http\Middleware\JwtMiddleware;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['namespace' => 'V2'], function () {
    Route::post('get-access-key', [UserController::class, 'getAuthToken']);
});

Route::group(['namespace' => 'V2', 'middleware' => ['verify.token']], function () {

    //authenticate by Jwt-token
    Route::group(['middleware' => ['jwt.verify']], function () {     
        Route::post('transaction-list', [PlaidApiController::class, 'transactionList']);        
        Route::get('get-category', [PlaidApiController::class, 'get_category']);
    });
});