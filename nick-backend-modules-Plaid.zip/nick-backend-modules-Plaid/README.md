# Plaid Integration Guide

This guide provides steps for integrating Plaid using cURL, including retrieving access tokens, transactions, and categories.

## Prerequisites

You will need the following details from the client:
- `plaid_client_id`
- `plaid_secret_id`

## Steps

### 1. Get Plaid Access Token

From the front-end, obtain the Plaid `access_token` for each user. This is required for accessing user-specific financial data.

### 2. Retrieve Transactions

Use the `transaction_details` API to get transactions and save them into your database. You should run a cron job every night to retrieve the list of today's transactions.

#### Cron Job Setup

Add the following line to your crontab to run once a day at 11:59 PM:

59 23 * * * curl -s "http://your-domain.com/plaid-transaction" > /dev/null



#### Route Configuration

Add the following route in `web.php`:

```php
Route::get('plaid-transaction', [PlaidApiController::class, 'transaction_details']);
```


### 3. Retrieve Plaid Transaction Categories

Use the `add_category` API to get transaction categories and save them into your database.

#### Route Configuration
Add the following route in web.php:

```php
Route::get('add-category', [PlaidApiController::class, 'add_category']);
```

### 4. Retrieve Plaid Categories on Front-End
Use the `get_category` API to fetch Plaid categories on the front-end.

#### Route Configuration
Add the following route in api.php:

```php
Route::get('get-category', [PlaidApiController::class, 'get_category']);
```


### 5. Retrieve User Transactions on Front-End
Use the `transactionList` API to fetch specific user transactions on the front-end.

#### Route Configuration
Add the following route in api.php:

```php
Route::post('transaction-list', [PlaidApiController::class, 'transactionList']);
```

## Note
This sample code demonstrates how to use the Yelp API. Update this module according to your project requirements. Ensure to replace `"http://your-domain.com/plaid-transaction"` with the actual URL of your application.

