<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Config;
use Carbon;
use JWTAuth;
use App\Models\PlaidCategory;
use App\Models\PlaidTranscation;    
use App\Models\User;    

class PlaidApiController extends Controller
{
    public function transaction_details(Request $request) 
    {   
        try{
            $users = User::orderBy('id','ASC')->get();

            date_default_timezone_set("UTC");
            $currDate = (date('Y-m-d'));
            foreach($users as $user)
            {
                $data =[
                    "client_id" => $user->client_id,
                    "secret" => $user->secret_id,
                    "access_token" => $user->access_token,
                    "start_date" =>  $currDate,
                    "end_date" => $currDate,
                    "options" => [
                        "count" => 100,
                        "include_personal_finance_category" =>  true,
                        // "account_ids" => ["bnWnREGnevc4nv36VNrZtDpZ9vWXazuo9Ax99"], 
                    ]
                ];
            
                $ch = curl_init();
                // curl_setopt($ch, CURLOPT_URL, 'https://sandbox.plaid.com/transactions/get'); //sandbox url
                curl_setopt($ch, CURLOPT_URL, 'https://production.plaid.com/transactions/get'); //production url
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
                $headers = array();
                $headers[] = 'Content-Type: application/json';
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                $result = curl_exec($ch);
                if (curl_errno($ch)) {
                    echo 'Error:' . curl_error($ch);
                }
                curl_close($ch);
                $result = json_decode($result, true); 

                foreach($result['transactions'] as $transaction)
                { 
                    // save plaid_transaction
                    $Plaid_tr = PlaidTranscation::updateOrCreate([
                        'user_id' =>  $user->user_id,
                        'transaction_id' => $transaction['transaction_id'],
                    ], [
                        'user_id' =>  $user->user_id,
                        'transaction_id' => $transaction['transaction_id'],
                        'account_id' =>  $transaction['account_id'],
                        'amount' =>  $transaction['amount'],
                        'date' =>  $transaction['date'],
                        'category_id' =>  $transaction['category_id'],
                        'merchant_name' =>  $transaction['category_id'],
                        'transaction_type' => $transaction['transaction_type'],
                    ]);
                }                                 
            }  
            return response()->json(['status' => true, 'message' => 'Transaction details fetched successfully', 'data' => (object)[]]);
            
        } catch (Exception $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => []]);
        }
    }
   
    public function add_category(Request $request) 
    {   
        try{
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://sandbox.plaid.com/categories/get');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "{}");

            $headers = array();
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch);
            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            curl_close($ch);
            $result = json_decode($result, true); 
            
            foreach($result['categories'] as $cat)
            {     
                $category = new PlaidCategory();
                $category->category_id = $cat['category_id'];
                $category->group_code = $cat['group'];

                foreach($cat['hierarchy'] as $cat_name){ 
                    $category->category_name = $cat_name;
                }                
                $category->save();
            }
            return response()->json(['status' => true, 'message' =>'Category data fetched successfully','data' => []]);
        } catch (Exception $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'message' => $e->getMessage(), 'data' => []]);
        }
    }

    public function get_category(Request $request)
    {
        try {
            $category = PlaidCategory::all();              
            if ($category) {
                return response()->json(['status' => true, 'message' => 'Category list fetched successfully.','data' =>$category]);
            }
        } catch (Exception $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'message' => $e->getMessage(),'data'=>[]]);
        }
    }

    public function transactionList(Request $request)
    {             
        try {
            $user_id = JWTAuth::toUser(JWTAuth::getToken())->id;
                $validator = Validator::make($request->all(), [
                    'account_id'          => 'nullable',
                    'category_id'         => 'nullable',
                    'keyword'             => 'nullable',
                ]);
                if($validator->fails()) {
                    return response()->json(['status' => false, 'message' =>  $validator->errors()->first()]);
                }

                if($request->account_id)
                {
                    $transaction = PlaidTranscation::where('user_id',$user_id)->where('account_id',$request->account_id)->orderBy('id','Desc')->paginate(10);
                }else if($request->category_id){
                    $transaction = PlaidTranscation::where('user_id',$user_id)->where('category_id',$request->category_id)->orderBy('id','Desc')->paginate(10);
                }else{
                   $transaction = PlaidTranscation::where('user_id',$user_id)->orderBy('id','Desc')->paginate(10);
                }

                return response()->json(['status' => true, 'message' => "Transaction list fetched successfully.", 'data' => $transaction]);
        }catch(\Throwable $th){
            $this->status_code = 500;
            DB::rollBack();
            return response()->json(['status' => false, 'message' => $th->getMessage(), 'data' => []]);
        }
    }
}
