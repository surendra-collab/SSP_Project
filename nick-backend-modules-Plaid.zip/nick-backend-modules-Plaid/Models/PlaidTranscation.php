<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon;


class PlaidTranscation extends Model
{
    use HasFactory;
    public $table = "plaid-transcations";
    protected $fillable = ['transfer_status','user_id','amount','category_id','date','merchant_name','account_id','transaction_id','transaction_type'];

    public function getDateAttribute($value)
    {
        return Carbon\Carbon::createFromFormat('Y-m-d', $value)->format('m-d-Y');
    }
}

