<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlaidCategory extends Model
{
    use HasFactory;
    public $table = "plaid_categories";

    protected $hidden = ['created_at','updated_at'];
    //protected $fillable = [];
}

