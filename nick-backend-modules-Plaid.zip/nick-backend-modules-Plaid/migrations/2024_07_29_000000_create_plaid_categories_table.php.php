<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePlaidCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('plaid_categories', function (Blueprint $table) {
            $table->increments('id'); // This is equivalent to `int(11) NOT NULL AUTO_INCREMENT`
            $table->integer('category_id')->nullable(); // Equivalent to `int(11) DEFAULT NULL`
            $table->string('group_code', 100)->nullable(); // Equivalent to `varchar(100) DEFAULT NULL`
            $table->string('category_name', 255)->nullable(); // Equivalent to `varchar(255) DEFAULT NULL`
            $table->timestamps(); // This creates `created_at` and `updated_at` columns with timestamp type
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('plaid_categories');
    }
}

