<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePlaidTranscationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('plaid_transcations', function (Blueprint $table) {
            $table->increments('id'); // Equivalent to `int(11) NOT NULL AUTO_INCREMENT`
            $table->integer('user_id')->nullable(); // Equivalent to `int(11) DEFAULT NULL`
            $table->decimal('amount', 10, 2)->nullable(); // Equivalent to `decimal(10,2) DEFAULT NULL`
            $table->string('category_id', 255)->nullable(); // Equivalent to `varchar(255) DEFAULT NULL`
            $table->date('date')->nullable(); // Equivalent to `date DEFAULT NULL`
            $table->string('merchant_name', 255)->nullable(); // Equivalent to `varchar(255) DEFAULT NULL`
            $table->text('account_id')->nullable(); // Equivalent to `text`
            $table->text('transaction_id')->nullable(); // Equivalent to `text`
            $table->string('transaction_type', 255)->nullable(); // Equivalent to `varchar(255) DEFAULT NULL`
            $table->tinyInteger('transfer_status')->default(0); // Equivalent to `int(1) NOT NULL DEFAULT '0'`
            $table->timestamps(); // Creates `created_at` and `updated_at` columns with timestamp type
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('plaid_transcations');
    }
}
