<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClubTimingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('club_timings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('bar_id');
            $table->string('day');
            $table->string('start_time', 50)->nullable();
            $table->string('end_time', 50)->nullable();
            $table->timestamps(0);

            // Add foreign key constraint if needed
            // $table->foreign('bar_id')->references('id')->on('bars')->onDelete('cascade');
        });

        // Set table charset and collation
        DB::statement('ALTER TABLE club_timings CONVERT TO CHARACTER SET latin1 COLLATE latin1_swedish_ci;');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('club_timings');
    }
}
