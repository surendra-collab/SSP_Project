<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBarCategoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bar_category', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('bar_id');
            $table->unsignedBigInteger('category_id');
            $table->tinyInteger('status')->default(1);
            $table->timestamps();

            // Add foreign key constraints if needed
            // $table->foreign('bar_id')->references('id')->on('bars')->onDelete('cascade');
            // $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bar_category');
    }
}
