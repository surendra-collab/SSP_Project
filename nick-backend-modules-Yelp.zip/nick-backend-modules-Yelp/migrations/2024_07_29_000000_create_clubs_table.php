<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClubsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clubs', function (Blueprint $table) {
            $table->id();
            $table->string('strip_customer_id')->nullable();
            $table->string('email')->nullable();
            $table->string('password')->nullable();
            $table->string('remember_token');
            $table->string('bar_name')->charset('latin1')->collation('latin1_swedish_ci')->nullable();
            $table->string('bar_image')->charset('latin1')->collation('latin1_swedish_ci')->nullable();
            $table->string('bar_video')->charset('latin1')->collation('latin1_swedish_ci')->nullable();
            $table->text('bar_registration_no')->charset('latin1')->collation('latin1_swedish_ci');
            $table->string('contact_number')->nullable();
            $table->string('address')->nullable();
            $table->string('latitude')->nullable();
            $table->string('longitude')->nullable();
            $table->tinyInteger('status')->default(0);
            $table->enum('verification_status', ['Pending', 'Approved', 'Rejected'])->default('Pending');
            $table->tinyInteger('is_premium')->default(0);
            $table->tinyInteger('is_emailed')->default(0);
            $table->unsignedInteger('plan_id')->nullable();
            $table->string('timezone')->nullable();
            $table->tinyInteger('is_yelp_bar')->default(0);
            $table->string('yelp_business_id')->nullable();
            $table->timestamps(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clubs');
    }
}
