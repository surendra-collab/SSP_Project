<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Carbon;
use App\Models\Club;
use App\Models\Tag;
use App\Models\BarCategory;
use App\Models\ClubTiming;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\QueryException;

class CronController extends Controller
{

    //fetch bar from yelp api and store it in database
    public function fetchYelpBar()
    {
        \Log::info('fetchYelpBar cron triggered');

        $limit = 40; // Results per page
        $totalBusinesses = [];
        $yelpTotalRecordLimit = 240;

        $offset = 0;
        do {
            $yelpSearchResult = $this->yelpSearchAPI($offset, $limit);

            if ($yelpSearchResult && isset($yelpSearchResult->businesses)) {
                $businesses = $yelpSearchResult->businesses;
                $totalBusinesses = array_merge($totalBusinesses, $businesses);
                $offset += $limit;
            } else {
                break; // Break the loop if there's an error or no more results
            }

        } while (count($totalBusinesses) < $yelpTotalRecordLimit); // Continue until all businesses are fetched


        // Now $totalBusinesses contains all businesses fetched from Yelp API
        foreach ($totalBusinesses as $business) {
            $business_detail = $this->yelpBusinessDetailAPI($business->id);
            if ($business_detail) {

                // Check if the business already exists
                $isBusinessExist = Club::where('yelp_business_id', $business->id)->exists();

                if (!$isBusinessExist) {
                    DB::beginTransaction();
                    try {

                        $latitude = $business->coordinates->latitude ?? NULL;
                        $longitude = $business->coordinates->longitude ?? NULL;

                        $address = "";
                        $business_address = isset($business->location) ? $business->location->display_address : NULL;

                        if ($business_address) {
                            foreach ($business_address as $key => $display_address) {
                                $separation = ($key < count($business_address) - 1) ? ", " : "";
                                $address .= $display_address . $separation;
                            }
                        }


                        //code to get timezone
                        $club = new Club();
                        $club->bar_name = $business->name ?? "Yelp Bar";
                        $club->contact_number = $business->phone ?? NULL;
                        $club->address = $address;
                        $club->latitude = $latitude;
                        $club->longitude = $longitude;
                        $club->verification_status = 'Approved';
                        $club->status = 1;
                        $club->is_yelp_bar = 1;
                        $club->yelp_business_id = $business->id;

                        $business_image_url = $business->image_url ?? "";
                        //saving bar image
                        if ($business_image_url != "") {
                            $rand = mt_rand(100000, 999999);

                            $contents = file_get_contents($business_image_url);
                            $imageName = $business->id . $rand . time() . '.' . substr($business_image_url, strrpos($business_image_url, '/') + 1);
                            $imagePath = '/uploads/club/' . $imageName;
                            $upload_status = Storage::disk('public_uploads')->put($imagePath, $contents);

                            if ($upload_status) {
                                $club->bar_image = 'public' . $imagePath;
                            } else {
                                //save default image if uploading bar image failed.
                                $club->bar_image = 'public/img/1676366618.png';
                            }
                        } else {
                            //save default image if uploading bar image failed.
                            $club->bar_image = 'public/img/1676366618.png';
                        }

                        $club->save();


                        //Saving bar category
                        $categories = $business->categories;

                        foreach ($categories as $category) {

                            $cat = Tag::firstOrCreate([
                                'tag_name' => $category->title
                            ], [
                                'tag_image' => 'public/img/tag/yelp_logo.jpg',
                                'tag_status' => 0,
                            ]);


                            $store = new BarCategory();
                            $store->bar_id = $club->id;
                            $store->category_id = $cat->id;
                            $store->status = 0;
                            $store->save();
                        }


                        //saving bar timing
                        $weeks = [
                            'Monday',
                            'Tuesday',
                            'Wednesday',
                            'Thursday',
                            'Friday',
                            'Saturday',
                            'Sunday'
                        ];

                        $weekly_working = isset($business_detail->hours) ? $business_detail->hours[0]->open : NULL;

                        foreach ($weeks as $key => $week) {

                            $startTime = NULL;
                            $endTime = NULL;

                            if ($weekly_working) {

                                if (isset($weekly_working[$key])) {
                                    $startTime = \Carbon\Carbon::createFromFormat('Hi', $weekly_working[$key]->start)->format('h:i A');
                                    $endTime = \Carbon\Carbon::createFromFormat('Hi', $weekly_working[$key]->end)->format('h:i A');
                                }
                            }

                            $store = new ClubTiming();
                            $store->bar_id = $club->id;
                            $store->day = $week;
                            $store->start_time = $startTime;
                            $store->end_time = $endTime;
                            $store->save();
                        }

                        DB::commit();
                    } catch (QueryException $e) {
                        DB::rollBack();
                    } catch (\Exception $e) {
                        DB::rollBack();
                    }

                }
            }
        }

        echo "fetchYelpBar cron Done";
        \Log::info('fetchYelpBar cron finished');

    }




    function yelpSearchAPI($offset = 0, $limit = 50)
    {

        $yelp_authorization_token = \Config::get('constants.YELP_AUTHORIZATION_TOKEN');

        $location = 'us'; // Adjust location as needed
        $term = 'bar'; // Adjust search term as needed

        $apiURL = "https://api.yelp.com/v3/businesses/search?location=$location&term=$term&limit=$limit&offset=$offset";

        $headers = array(
            'Authorization: Bearer ' . $yelp_authorization_token,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiURL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        if ($result === FALSE) {
            curl_close($ch);
            return false;
        } else {
            $result = json_decode($result);
            curl_close($ch);
            return $result;
        }
    }


    function yelpBusinessDetailAPI($business_id)
    {
        $yelp_authorization_token = \Config::get('constants.YELP_AUTHORIZATION_TOKEN');

        $apiURL = "https://api.yelp.com/v3/businesses/$business_id";

        $headers = array(
            'Authorization: Bearer ' . $yelp_authorization_token,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiURL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        if ($result === FALSE) {
            curl_close($ch);
            return false;
        } else {
            $result = json_decode($result);
            curl_close($ch);
            return $result;
        }
    }

}
