<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class ClubTiming extends Model
{
    use HasFactory;

    public $table = "club_timings";

    protected $fillable = ['bar_id', 'day', 'start_time', 'end_time'];

}


