<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Auth;
use Illuminate\Foundation\Auth\User as Authenticatable;


class Club extends Authenticatable
{
    use HasFactory;
    use Notifiable;

    public $table = "clubs";
    
    protected $guard = "club";

    protected $fillable = ['strip_customer_id', 'email', 'password', 'remember_token', 'bar_name', 'bar_image', 'bar_video', 'bar_registration_no', 'contact_number', 'address', 'latitude', 'longitude', 'status', 'verification_status', 'is_premium', 'is_emailed', 'plan_id', 'timezone', 'is_yelp_bar', 'yelp_business_id'];

    protected $hidden = [
        'password',
        'remember_token',
    ];
  
}
