# Yelp Integration Guide

This guide provides steps for integrating the Yelp Fusion API using cURL. Here, we fetch a list of bars and their details and store them in the database.

### What is the Yelp Fusion API?

The Yelp Fusion API allows you to access the best local content and user reviews from millions of businesses around the world.

### Yelp Fusion API URL

For more information, visit the [Yelp Fusion API Documentation](https://docs.developer.yelp.com/docs/fusion-intro).

## Prerequisites

You will need the following details from the client:
- `Authorization_token`

### Route Configuration

Add the following route in `web.php`:

```php
Route::get('fetch-yelp-bar', [CronController::class, 'fetchYelpBar']);
```

## Note
This sample code demonstrates how to use the Yelp API. Update this module according to your project requirements.