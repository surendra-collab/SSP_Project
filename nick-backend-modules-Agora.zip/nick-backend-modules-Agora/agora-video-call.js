require('dotenv').config();

const port = process.env.PORT;  // Socket Port
const app_name = process.env.PROJECT_NAME;

const express = require('express');
const moment = require('moment');
const app = express();
const http = require('http').Server(app); // Including http package and creating an application
const mysql = require('mysql');   //  Including mysql package123
const { RtcTokenBuilder, RtcRole } = require("agora-access-token");

if (process.env.FCM_FILEPATH != "") {
    var firebase_admin = require('firebase-admin');
    var firebase_path = process.env.FCM_FILEPATH;
    var serviceAccount = require(firebase_path);

    firebase_admin.initializeApp({
        credential: firebase_admin.credential.cert(serviceAccount)
    });
    const fcm = firebase_admin.messaging();
}



let user_default_img = "public/assets/common/images/default-avatar.png";

let io = require('socket.io')(http, {
    // cors: {
    //     origin: host_url,
    //     methods: ["GET", "POST"]
    // }
});    //  Including socket.io package


const agora_app_ID = process.env.AGORA_APP_ID;
const agora_app_certificate = process.env.AGORA_APP_CERTIFICATE;

let con = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB,
    charset: 'utf8mb4',
    dateStrings: true
});


/*
    Setting mysql connection
*/
con.connect((err) => {
    if (err) {
        return showInLog(err);
    }
    showInLog("Database Connected");
    // setting default state of all users
    dbDefault();
});

let sockets = {};
var call_data = {};
var video_call_user = [];
var user_chat_screen = [];

app.get('/', function (req, res) {
    //res.render('chat', { socket_url: host_url });
    res.sendFile(__dirname + '/index.html');
});

/*
    Socket Connection Bridge
*/
io.on('connection', async function (socket) {

    //---------------- Show which user is gets connect -------------------------------------
    showInLog(`User Connected : ${socket.handshake.query.user_id}`);
    var user_id = socket.handshake.query.user_id;

    //---------------- Make a room in pool for the user if new user ------------------------
    if (!sockets[socket.handshake.query.user_id]) {
        sockets[socket.handshake.query.user_id] = [];
    }

    //---------------- Get user detail and add socket connection object in the pool array ----------------------
    await getUser(socket.handshake.query.user_id).then((user) => {
        socket.user_detail = user;
        if (sockets[socket.handshake.query.user_id].length <= 0) {
            sockets[socket.handshake.query.user_id].push(socket);
        }
    }).catch((err) => {
        throw err;
    });

    //---------------- Update user online status -------------------------------------------
    updateOnlineStatus(socket.handshake.query.user_id);


    //--------------------------- Disconnect user----------------------------------
    socket.on('disconnect', function (reason) {
        showInLog(`User Disconnected : ${socket.handshake.query.user_id}`);
        showInLog(`Reason : ${reason}`);

        //---------------- Update user online status -------------------------------------------
        updateOnlineStatus(socket.handshake.query.user_id, 0);

        //---------------- Remove user from socket pool array -------------------------------------------
        delete sockets[socket.handshake.query.user_id];

    });


    //...........................Agora video calling start........................

    //...........................call connect...............................*/
    socket.on('call_connection', function (data, cb) {

        getUser(user_id).then((user_data) => {
            showInLog(`call connect user data: ${user_data}`);
            showInLog(user_data);

            getUser(data.other_user_id).then((other_user_data) => {

                showInLog(`call connect other user data: ${other_user_data}`);
                showInLog(other_user_data);

                var scheduleCallId = null;
                //this key is optional user only when call is scheduled
                if (data.schedule_call_id !== undefined && data.schedule_call_id !== "") {
                    scheduleCallId = data.schedule_call_id;
                }


                data.receiver_image = other_user_data.profile_image;
                data.receiver_name = other_user_data.name;

                data.sender_image = user_data.profile_image;
                data.sender_name = user_data.name;

                callBusyStatus(data.other_user_id).then((busyStatus) => {
                    showInLog('call busy status: ' + busyStatus);
                    if (busyStatus) {
                        //user is on another call

                        showInLog('call busy');
                        showInLog(video_call_user);

                        let callResult = {
                            status: true,
                            message: "Successfully call connect.",
                            data: {
                                group: data.group_id,
                                call_token: '',
                                receiver: parseInt(data.other_user_id),
                                receiver_name: data.receiver_name,
                                receiver_image: data.receiver_image,
                                sender: parseInt(user_id),
                                sender_name: data.sender_name,
                                sender_image: data.sender_image,
                                is_reject: 0,
                                is_connect: 0,
                                is_received: 0,
                                is_on_another_call: 1,
                                schedule_call_id: scheduleCallId,
                            }
                        }

                        showInLog('user is on another call');
                        showInLog(callResult);

                        cb(callResult);
                    } else {

                        generateRtcToken(user_id, data).then((result) => {
                            result.data.schedule_call_id = scheduleCallId;
                            cb(result);


                            //set both user id's in video_call_user array
                            callConnected(user_id);
                            callConnected(data.other_user_id);

                            showInLog('call connect array');
                            showInLog(video_call_user);


                            call_data = {
                                group: data.group_id,
                                call_token: result.data.call_token,
                                call_channel: result.data.call_channel,
                                receiver: parseInt(data.other_user_id),
                                receiver_name: data.receiver_name,
                                receiver_image: data.receiver_image,
                                sender: parseInt(user_id),
                                sender_name: data.sender_name,
                                sender_image: data.sender_image,
                                is_reject: 0,
                                is_connect: 0,
                                is_received: 0,
                                is_on_another_call: 0,
                                schedule_call_id: scheduleCallId,
                            };

                            let receiver_data = {
                                status: true,
                                message: "Successfully connect.",
                                data: {
                                    group: data.group_id,
                                    call_token: result.data.call_token,
                                    call_channel: result.data.call_channel,
                                    receiver: parseInt(data.other_user_id),
                                    receiver_name: data.receiver_name,
                                    receiver_image: data.receiver_image,
                                    sender: parseInt(user_id),
                                    sender_name: data.sender_name,
                                    sender_image: data.sender_image,
                                    is_reject: 0,
                                    is_connect: 0,
                                    is_received: 0,
                                    is_on_another_call: 0,
                                    schedule_call_id: scheduleCallId,
                                }
                            }

                            showInLog('call connect');

                            // send notification
                            let msg = 'Call from ' + user_data.name;
                            let msg_action = 'AGORA_VIDEO_CALL';
                            initiatingNotification(data.other_user_id, msg, msg_action, receiver_data);


                            showInLog('sending to receiver call data');
                            showInLog(receiver_data);

                            if (sockets[data.other_user_id] != undefined) {
                                for (let index in sockets[data.other_user_id]) {
                                    showInLog('sending to receiver');
                                    showInLog(receiver_data);
                                    sockets[data.other_user_id][index].emit('receiver_call_connect', receiver_data);
                                }
                            }


                        }).catch((err) => {
                            throw err;
                        });
                    }
                }).catch((err) => {
                    throw err;
                });

            }).catch((err) => {
                throw err;
            });
        }).catch((err) => {
            throw err;
        });


    });


    //...........................call receive...............................*/
    socket.on('accept_call', function (data, cb) {

        showInLog(data);

        call_data.is_received = 1;
        call_data.is_connect = 1;
        call_data.is_reject = 0;
        call_data.is_on_another_call = 0;


        let receiver_data = {
            status: true,
            message: "Successfully received.",
            data: call_data,
        }
        cb(receiver_data);

        if (sockets[data.other_user_id] != undefined) {
            for (let index in sockets[data.other_user_id]) {
                showInLog('call receive listener calling');
                showInLog(receiver_data);
                sockets[data.other_user_id][index].emit('call_accepted', receiver_data);
            }
        }


    });


    //...........................call reject...............................*/
    socket.on('reject_call', function (data, cb) {

        showInLog(data);

        call_data.is_received = 0;
        call_data.is_connect = 0;
        call_data.is_reject = 1;
        call_data.is_on_another_call = 0;

        let receiver_data = {
            status: true,
            message: "Successfully rejected.",
            data: call_data,
        }
        cb(receiver_data);

        //unset both user id's from video_call_user array
        callDisconnected(user_id);
        callDisconnected(data.other_user_id);

        let qry = `UPDATE call_token SET call_token = NULL WHERE group_code = '${data.group_id}'`;
        con.query(qry, function (err, result) {
            if (err) {
                throw err;
            }

            if (sockets[data.other_user_id] != undefined) {
                for (let index in sockets[data.other_user_id]) {
                    showInLog('call reject listener calling');
                    showInLog(receiver_data);
                    sockets[data.other_user_id][index].emit('call_rejected', receiver_data);

                    setTimeout(() => {
                        //empty call data
                        call_data = {};
                    }, 2000);

                }
            }

        });

    });



    //...........................call Disconnect...............................*/
    socket.on('call_disconnect', function (data, cb) {

        let qry = `UPDATE call_token SET call_token = NULL WHERE group_code = '${data.group_id}'`;
        con.query(qry, function (err, result) {
            if (err) {
                throw err;
            }
            showInLog("call Disconnected");

            call_data.is_received = 0;
            call_data.is_connect = 0;
            call_data.is_reject = 0;
            call_data.is_on_another_call = 0;

            //unset both user id's from video_call_user array
            callDisconnected(user_id);
            callDisconnected(data.other_user_id);

            showInLog('call disconnect array');
            showInLog(video_call_user);

            let receiver_data = {
                status: true,
                message: "Successfully disconnect.",
                data: call_data
            }
            cb(receiver_data);

            if (sockets[data.other_user_id] != undefined) {
                for (let index in sockets[data.other_user_id]) {
                    showInLog('call disconnected executing listener');
                    showInLog(receiver_data);
                    sockets[data.other_user_id][index].emit('call_disconnected', receiver_data);
                    setTimeout(() => {
                        //empty call data
                        call_data = {};
                    }, 2000);
                }
            }
        });
    });

    //...........................Agora video calling end........................






});


//------------------ generating token from agora through api -------------------
function generateRtcToken(user_id, arg_data) {
    return new Promise((resolve, reject) => {
        generateChannelName(15).then((channelName) => {


            // Rtc Connect
            const appID = agora_app_ID;
            const appCertificate = agora_app_certificate;
            const role = RtcRole.PUBLISHER;

            // use 0 if uid is not specified
            let uid = 0
            if (!channelName) {
                return reject({ 'error': 'channel name is required' });
            }
            let key = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channelName, uid, role);


            con.query(`update call_token set call_token = '${key}', call_channel = '${channelName}' where group_code = '${arg_data.group_id}'`, function (err, result) {
                if (err) {
                    return reject(err);
                }
                showInLog(`Agora Token : ${key}`);

                let call_data = {
                    status: true,
                    message: "Successfully call connect.",
                    data: {
                        group: arg_data.group_id,
                        call_token: key,
                        call_channel: channelName,
                        receiver: parseInt(arg_data.other_user_id),
                        receiver_name: arg_data.receiver_name,
                        receiver_image: arg_data.receiver_image,
                        sender: parseInt(user_id),
                        sender_name: arg_data.sender_name,
                        sender_image: arg_data.sender_image,
                        is_reject: 0,
                        is_connect: 0,
                        is_received: 0,
                    }
                }

                return resolve(call_data);
            })
        })

    })
};


//-----------check user is on another call or not
function callBusyStatus(userID) {
    userID = parseInt(userID);
    return new Promise((resolve, reject) => {
        let status = video_call_user.includes(userID);
        return resolve(status);
    });
}
function callDisconnected(userID) {
    userID = parseInt(userID);
    const index = video_call_user.indexOf(userID);
    if (index > -1) { // only splice array when item is found
        video_call_user.splice(index, 1); // 2nd parameter means remove one item only
    }

    showInLog('call disconnted array');
    showInLog(video_call_user);
}
function callConnected(userID) {
    userID = parseInt(userID);
    video_call_user.push(userID);
}


//generate unique random string
function generateChannelName(length) {
    return new Promise(function (resolve, reject) {

        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const charactersLength = characters.length;
        let counter = 0;
        while (counter < length) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
            counter += 1;
        }
        result += Date.now();

        return resolve(result);
    })

}


//------------------ Update online status -------------------
function updateOnlineStatus(user_id, status = 1) {
    new Promise((resolve, reject) => {
        let qry = `UPDATE users SET online = ${status} WHERE id = ${user_id}`;
        con.query(qry, function (err, result) {
            if (err) {
                showInLog(err);
                return reject(err);
            }
            status ? (function () {
                showInLog(`User ${user_id} : ONLINE`);
                // messageDelivered(user_id);  // update message status AS delivered
            })() : showInLog(`User ${user_id} : OFFLINE`);


            return resolve(true);
        });
    });
}

//------------------ Get user detail -------------------
function getUser(user_id) {

    return new Promise((resolve, reject) => {
        con.query(`SELECT id, name, case when profile_picture is null then '${user_default_img}' ELSE profile_picture end AS profile_image FROM users WHERE id = ${user_id} `, function (err, result) {
            if (err) {
                return reject(err);
            }
            return resolve(result[0]);

        })
    })
}


//------------------ Db default status -------------------
function dbDefault() {
    new Promise((resolve, reject) => {
        let qry = `UPDATE users SET online = 0`;
        con.query(qry, function (err, result) {
            if (err) {
                return reject(err);
            }
            showInLog("DB successfully set to default");
            return resolve(true);
        });
    });
}



//------------------ Logging -------------------
function showInLog(log_data) {
    // console.log(log_data);
}

//send notification
async function initiatingNotification(other_user_id, msg, action, extra_data = '') {


    if (Array.isArray(other_user_id)) {

        let user_id = await other_user_id.join(',');

        var getDeviceTokenQry = `SELECT device_token FROM user_devices WHERE user_id IN (SELECT id FROM users WHERE notification_status = 1) AND user_id IN (${user_id}) AND device_token IS NOT NULL AND device_token <> ' '`;

    } else {

        var getDeviceTokenQry = `SELECT device_token FROM user_devices WHERE user_id IN (SELECT id FROM users WHERE notification_status = 1) AND user_id = ${other_user_id} AND device_token IS NOT NULL AND device_token <> ' '`;

    }

    showInLog(getDeviceTokenQry);
    con.query(getDeviceTokenQry, async function (err, result) {
        if (err) {
            showInLog('error when getting device token to send notification');
            showInLog(err);
            // return reject(err);
        }

        if (result !== undefined && result.length > 0) {
            let device = await result.map((data) => data.device_token);
            showInLog('Sending notification');
            showInLog(device)
            sendNotification(device, msg, action, extra_data);
        }

    });
}



//firebase send notification
var sendNotification = function (device, message, action, extra_data = '') {

    if (extra_data != '') {
        extra_data.type = action;
    }

    var notification_extras = {
        type: action,
        extras: extra_data
    }

    // Convert all values in notification_extras to strings
    var data = {};
    for (let key in notification_extras) {
        if (typeof notification_extras[key] === 'string' || notification_extras[key] instanceof String) {
            data[key] = notification_extras[key];
        } else {
            data[key] = JSON.stringify(notification_extras[key]);
        }
    }

    var payload = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
        tokens: Array.isArray(device) ? device : [device],
        notification: {
            title: app_name,
            body: message
        },
        data: data
    }


    fcm.sendMulticast(payload)
        .then((response) => {
            showInLog("Notification successfully sent with response: ", response);
        })
        .catch((err) => {
            showInLog(err);
            showInLog("Something has gone wrong while sending notification!");
        });
}
//---------------------------- Start listening on this port ---------------------------------
http.listen(port, () => showInLog(`Listening on port: ${port} `));
