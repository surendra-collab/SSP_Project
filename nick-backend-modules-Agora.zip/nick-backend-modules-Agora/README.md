# Agora Integration Guide

This guide provides steps for integration of agora video calling in node Js.

## Prerequisites

You will need the following details:
- `Android JSON file for notifications`
- `Node Js installed on your system`
- `PM2 installed`


# Instruction to setup:

```sh
npm install
pm2 start <file name>
```

## Note
This module only includes Agora events and Agora token generation code. Update this module according to your project requirements.
