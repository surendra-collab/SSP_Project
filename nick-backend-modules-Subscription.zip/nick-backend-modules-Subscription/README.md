# In-app purchase(Subscription) Integration Guide

This guide provides steps for integrating the In-app purchase in project. This module validate both subscription and product receipt.


# Install Required package:

```sh
composer require aporat/store-receipt-validator
```


## Prerequisites

You will need the following details:
- `IOS Secret key`
- `Android Json file`


## Routes

#### API routes:

```php
    Route::post('purchase-plan', [InAppController::class, 'purchasePlan']);
    Route::post('purchase-restore', [InAppController::class, 'purchaseRestore']);
    Route::get('get-plan-list', [InAppController::class, 'getPlanList']);
```

#### Web routes:

```php
    Route::group(['prefix' => 'cron'], function(){
        Route::any('check-subscription-expiry', [InAppController::class, 'subscriptionStatusCron']);
    });
```

## Note
This sample code demonstrates how to integrate In-app purchase module. Update this module according to your project requirements.
